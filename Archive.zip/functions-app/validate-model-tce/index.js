const { successResponse } = require('../common/response');
const { connectToDB } = require('../db-connections/dbConfig');
const { initiateModelTCEUpdation } = require('./validate-model-tce.service');
require('dotenv').config();

module.exports = function (context, req) {
    connectToDB().then(async () => {
        const response = await initiateModelTCEUpdation();
        context.res = successResponse(response);
        context.log('Model TCE Updation executed successfully');
        context.done();
    }).catch(error => {
        context.log('Model TCE Updation error: ', error);
        throw error;
    })
    
    

    
}
