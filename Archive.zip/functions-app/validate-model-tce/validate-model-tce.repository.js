const gvsl = require("../models/gvsl.model");
const Vcarvest = require("../models/vcarvestSchema.model");
const Itinvest = require("../models/itinvestSchema.model");
const VoyageDraft = require("../models/voyageDraft.model");
const Regions = require("../models/regions.model");
const VschedVsl = require("../models/vsched.model");
const SeaConsumptionRate = require("../models/seaConsumptionRate.model");
const PortConsumptionRate = require("../models/portConsumptionRate.model");
const { GLOBAL_FLEET, CREATE_VOYAGE_REQUEST_STATUS } = require("../common/common_constant");
const createVoyageLogsModel = require("../models/createVoyageLogs.model");

const getSavedDraftData = () => {
    return VoyageDraft.find({ isDeleted: false, isValid: true });
}


const getVesselDetailsAndJourney = async(vslCode, voyNum) => {
    return gvsl.aggregate([
        { $match: { vsl_code : vslCode, isDeleted: false, fleet: GLOBAL_FLEET.STJS }},
        {
            $lookup: {
                from: "vsched",
                localField: "vsl_code",
                foreignField: "ves_code",
                as: "journey",
            },
        },
        {$unwind:'$journey'},
        {
            $match:
            {
                'journey.isDeleted':false,
                'journey.voy_no_int':{ $lte: voyNum },
                $or: [
                    {
                      'journey.bnkr_price_0' : { $ne: 0 }
                    },
                    {
                      'journey.bnkr_price_1' : { $ne: 0 }
                    },
                    {
                      'journey.bnkr_price_2' : { $ne: 0 }
                    }
                  ]
            }
    },
    {
        $sort: { 'journey.voy_no_int': -1, 'journey.ord_no_int': -1}
    },
    {
        $project: {
            vsl_code: 1,
            vsl_name: 1,
            vsl_type: 1,
            yearBuilt: 1,
            dwt: 1,
            voy_no_int: '$journey.voy_no_int',
            ord_no_int: '$journey.ord_no_int',
            bnkr_fuelType_0: '$journey.bnkr_fuelType_0',
            bnkr_fuelType_1: '$journey.bnkr_fuelType_1',
            bnkr_fuelType_2: '$journey.bnkr_fuelType_2',
            bnkr_price_0: '$journey.bnkr_price_0',
            bnkr_price_1: '$journey.bnkr_price_1',
            bnkr_price_2: '$journey.bnkr_price_2',
            fleet:1,
            _id: 0
        }
    }
    ]);
}

const getModelVoyagesDataTables = async(vsl_voy_ids) => {
    return Vcarvest.aggregate([
        { $match: { vsl_voy_id: { $in: vsl_voy_ids}, isDeleted: false}},
        { $group: { _id: "$vsl_voy_id", vcarvestData: { $push: "$$ROOT"}} },
        {
            $lookup: {
                from: "brkvest",
                localField: "vcarvestData.vsl_voy_id",
                foreignField: "vsl_voy_id",
                as: "brkvestData",
            }
        },
        {
            $addFields: {
                brkvestData: {
                    $filter: {
                        input: "$brkvestData",
                        as: "brk",
                        cond: { $ne: ["$$brk.isDeleted", true] }
                    }
                }
            }
        },
        {
            $lookup: {
                from: "expvest",
                localField: "vcarvestData.vsl_voy_id",
                foreignField: "vsl_voy_id",
                as: "expvestData",
            }
        },
        {
            $addFields: {
                expvestData: {
                    $filter: {
                        input: "$expvestData",
                        as: "exp",
                        cond: { $ne: ["$$exp.isDeleted", true] }
                    }
                }
            }
        }
    ]);
}

const getModelVoyagesWithJourney = async(regex) => {
    return Itinvest.aggregate([
         { $match: { vsl_voy_id: {  $in: regex  }, isDeleted: false}},
         { $sort: { num: 1 } },
         { $group: {_id: "$vsl_voy_id", journey: {  $push: "$$ROOT"}}},
    ]);
}

const getVoyageDraft = async (estimateID,vesVoy) => {
    return VoyageDraft.find({estimateID,vesVoy,isDeleted:false,isValid:true});
}

const getRegionsByParentRegion = async(parentRegion)=>{
    return Regions.find(parentRegion);
}

const getSpeedDetails = async(vesCode, voyNum) => {
    return VschedVsl.aggregate([
      {
        $match: {
          ves_code: vesCode.toString(),
          isDeleted: false,
          voy_no_int : { $lte: voyNum },
          spd: { $ne: 0 },
        }
      },
      {
        $sort: { voy_no_int: -1, ord_no_int: -1 },
      },
      {
        $project: {
          ves_code: 1,
          voy_no_int: 1,
          ord_no_int: 1,
          spd: 1,
          _id: 0,
        },
      },
      {
        $limit:1
      }
    ]);
}

const getSeaConsumptionRatesData = async(vsl_type) =>{
    return SeaConsumptionRate.findOne({ vsl_type });
}

const getPortConsumptionRatesData = async()=>{
    return PortConsumptionRate.find({}).select({ _id: 0 }).lean().exec();
}

const updateDraftVoyage = (vesVoy, tce) => {
    return VoyageDraft.findOneAndUpdate({ vesVoy, isDeleted: false, isValid: true }, { modelVoyageTCE: tce.toString() }, { new: false });
}
module.exports = {
    getSavedDraftData,
    getVesselDetailsAndJourney,
    getModelVoyagesDataTables,
    getVoyageDraft,
    getRegionsByParentRegion,
    getSpeedDetails,
    getModelVoyagesWithJourney,
    getSeaConsumptionRatesData,
    getPortConsumptionRatesData,
    updateDraftVoyage
}


