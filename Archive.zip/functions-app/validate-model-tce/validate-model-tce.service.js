const { MODEL_VOYAGE, NO_OF_FUEL_TYPES, PERCENTAGE_OF_FUELS, SHIP_TYPE, FUNCION_VALUES } = require("../common/common_constant");
const { getVesselDetailsAndJourney, getModelVoyagesDataTables, getVoyageDraft, getRegionsByParentRegion, getSpeedDetails, getModelVoyagesWithJourney, getSeaConsumptionRatesData, getPortConsumptionRatesData, getSavedDraftData, updateDraftVoyage } = require("./validate-model-tce.repository");

const initiateModelTCEUpdation = async () => {
    const draftVoyages = await getSavedDraftData();;
    const result = await Promise.all(draftVoyages.map(async (draft) => {
        const { vslCode, vesVoy, region, voyNum, estimateID, modelVoyageTCE } = draft;
        const modelTCEList = await getModelVoyages({ vslCode, vesVoy, region, voyNum});
        const {tce} = await modelTCEList.find(tce => tce.estimateId == estimateID);
        if (tce.toString() !== modelVoyageTCE) {
            await updateDraftVoyage(vesVoy, tce)
            return estimateID;
        }
    }));
    return result;
}

const getModelVoyages = async (payload) => {
    try {
        let lobData = await getRegionData({ parent_region: payload.region });
    
        const regex = lobData.map(data => { return new RegExp(`${MODEL_VOYAGE.ESTIMATE_ID_CONSTANT}/` + data.LOB, "i") });
        const shipDetails = await getVesselDetailsAndJourney(payload.vslCode, +payload.voyNum);
        const [vesselSpeed]= await getVesselSpeedInfo(payload.vslCode, +payload.voyNum);
        
        const vesVoy = `${payload.vesVoy}`;
        
        const dataList = [];
        const modelVoyagesWithJourney = await getModelVoyagesWithJourney(regex);
        const modelVoyages = modelVoyagesWithJourney.map(details => details._id);
        const { dwt, vsl_type } = shipDetails && shipDetails.length ? shipDetails[0] : '';
        const maxCapacity = MODEL_VOYAGE.SHIP_CAPACITY_MULTIPLIER * dwt;

        const seaConsumptionDetails = await getSeaConsumptionRates(vsl_type, vesselSpeed?.spd);
        const portConsumptionRate = await getPortConsumptionRates(vsl_type);

        const bunkerPrice = await calculateBunkerPrice(shipDetails);
        console.log('Calculated bunker price for ship', { bunkerPrice, vslCode: payload.vslCode, region: payload.region })

        const modelVoyageData = await getModelVoyagesDataTables(modelVoyages)
        for (const modelVoyage of modelVoyageData) {
            const { totalRevenue, contract, spot } = await getTotalExpense(modelVoyage, maxCapacity);
            const [voyageDraft] = await getVoyageDraft(modelVoyage._id,vesVoy);
            const savedVoyageDraft = voyageDraft ? true : false;
            const costInfoPayload = {
                modelVoyages: modelVoyage,
                seaConsumptionDetails,
                portConsumptionRate,
                costInfo: modelVoyagesWithJourney.find(details => details._id === modelVoyage._id)?.journey,
                bunkerPrice,
                vesselSpeed
            }
            const costInfo = bunkerPrice !== 0 ? await getConstInfo(costInfoPayload) : {};
            const tce = bunkerPrice !== 0 ? (totalRevenue - costInfo.totalExpense) / costInfo.totalVoyageDays : 0;
            dataList.push({ tce, bunkerPrice, savedVoyageDraft, estimateId: modelVoyage._id, contract, spot, startToEndJourney: costInfo.startToEndJourney })

        }
        return dataList;
    } catch (error) {
        console.log(error)
        return [];
    }
}

const getRegionData = async (parentRegion) => {
      const data = await getRegionsByParentRegion(parentRegion);
      return data ? data : "";
};

const getVesselSpeedInfo = async(vesCode, voyNum) => {
      return getSpeedDetails(vesCode, voyNum);
}

const getSeaConsumptionRates = async (vsl_type, consumption = null) => {
      const data = await getSeaConsumptionRatesData(vsl_type);
      const seaConsumptionRate = data && data.per_speed_consumption ? data.per_speed_consumption.find((_consumption) => _consumption.speed === consumption) : {};
  
      if(seaConsumptionRate) {
        return seaConsumptionRate;
      } else if(data && data.per_speed_consumption) {
        const closestSpeed = data.per_speed_consumption.reduce((acc, obj) => Math.abs(consumption - obj.speed) < Math.abs(consumption - acc.speed) ? obj : acc);
        return closestSpeed;
      }
};

const getPortConsumptionRates = async (vsl_type) => {
      const data = await getPortConsumptionRatesData();
      return data && data.length && data[0][vsl_type] ? data[0][vsl_type] : 0;
};

const calculateBunkerPrice = async (vesselJourney) => {
    let LSFPrice;
    let IFOPrice;
    let MGOPrice;

    for (const vesJourney of vesselJourney) {
        const mgoLsfIfoPrices = await getReqFuelTypePrices(vesJourney)

        if (!MGOPrice && mgoLsfIfoPrices.MGO > 0) {
            MGOPrice = mgoLsfIfoPrices.MGO;
        }
        if (!LSFPrice && mgoLsfIfoPrices.LSF > 0) {
            LSFPrice = mgoLsfIfoPrices.LSF;
        }
        if (!IFOPrice && mgoLsfIfoPrices.IFO > 0) {
            IFOPrice = mgoLsfIfoPrices.IFO;
        }

        if (MGOPrice && (LSFPrice || IFOPrice)) {
            break;
        }

    }

    let bunkerPrice = 0;
    if (MGOPrice > 0 && !IFOPrice && !LSFPrice) {
        bunkerPrice = MGOPrice;

    } else if (!MGOPrice && (IFOPrice > 0 || LSFPrice > 0)) {
        bunkerPrice = LSFPrice && LSFPrice > 0 ? LSFPrice : IFOPrice;

    } else if (MGOPrice > 0 && (IFOPrice > 0 || LSFPrice > 0)) {
        bunkerPrice = (PERCENTAGE_OF_FUELS.MGO * MGOPrice) + (PERCENTAGE_OF_FUELS.LSF_IFO * (LSFPrice && LSFPrice > 0 ? LSFPrice : IFOPrice))

    }
    return bunkerPrice;
};

const getTotalExpense = async (modelData, maxCapacity) => {
    // Revenue Information ******
    // 1. Cargo Revenue

    const cargoDetails = modelData.vcarvestData;
    let cpQtyCargo1;
    let cpQtyCargo2;

    const cargoVeCoa = cargoDetails.filter(data => data.cargo === SHIP_TYPE.VE_COA);
    const cargoVeSpot = cargoDetails.filter(data => data.cargo === SHIP_TYPE.VE_SPOT);
    let sumOfCpQty = 0;
    cargoVeCoa.forEach(cargo => {
        sumOfCpQty = sumOfCpQty + parseInt(cargo.cp_qty);
    });
    if (maxCapacity > sumOfCpQty) {
        cpQtyCargo1 = sumOfCpQty;
        cpQtyCargo2 = (cargoVeSpot && cargoVeSpot.length === 0) ? 0 : maxCapacity - sumOfCpQty;
    } else if (maxCapacity <= sumOfCpQty) {
        cpQtyCargo1 = maxCapacity;
        cpQtyCargo2 = 0;
    }

    const cargo1 = cargoVeCoa && cargoVeCoa.length ? cargoVeCoa[0] : null;
    const cargo2 = cargoVeSpot && cargoVeSpot.length ? cargoVeSpot[0] : null;

    const cargo1Seq = cargo1 && cargo1.cargoSeq ? cargo1.cargoSeq : "";
    const cargo2Seq = cargo2 && cargo2.cargoSeq ? cargo2.cargoSeq : "";
    const commissionDetails = await getCargoCommissionDetails(modelData.brkvestData, cargo1Seq, cargo2Seq);

    const cargo1FreightRate = cargo1 ? parseInt(cargo1.freight) : 0;
    const cargo2FreightRate = cargo2 ? parseInt(cargo2.freight) : 0;

    const cargo1Freight = cpQtyCargo1 * cargo1FreightRate;
    const cargo2Freight = cpQtyCargo2 * cargo2FreightRate;


    const totalFreight = cargo1Freight + cargo2Freight;

    // 2. Other Revenue 
    const cargo1CommissionRate = commissionDetails.cargo1Commission / 100;
    const cargo2CommissionRate = commissionDetails.cargo2Commission / 100;

    const cargo1CommissionRevenue = -(cargo1CommissionRate * cargo1Freight);
    const cargo2CommissionRevenue = -(cargo2CommissionRate * cargo2Freight);

    const totalCommissionRevenue = cargo1CommissionRevenue + cargo2CommissionRevenue;

    const vType = MODEL_VOYAGE.VTYPE_R;
    const miscellaneousRevenue = await getMiscellaneousRevenue(vType, modelData.expvestData);

    const totalRevenue = totalFreight + totalCommissionRevenue + miscellaneousRevenue;
    console.log('Calculated total revenue for estimate Id', { estimateId: modelData._id, totalRevenue })
    return { totalRevenue, contract: cpQtyCargo1, spot: cpQtyCargo2 };

};

const getConstInfo = async (payload) => {
    const { modelVoyages, seaConsumptionDetails, portConsumptionRate, costInfo, bunkerPrice, vesselSpeed } = payload;

    // cost information *******
    // 1. Fuel Cost
    let sailingDistance = 0;
    let portTime = 0;
    let portExpenses = 0;
    let tolls = 0;
    costInfo.forEach(data => {
        portTime = portTime + data.pdays + data.xpdays;
        sailingDistance += data.miles;
        if (data && data.func && data.func === FUNCION_VALUES.FUNCTION_I) {
            tolls += data.pexp;
        }
        if (data && data.func && data.func !== FUNCION_VALUES.FUNCTION_I) {
            portExpenses += data.pexp;
        }
    });

    const sailingTime = sailingDistance / (vesselSpeed?.spd * 24);

    const seaConsumptionRate = seaConsumptionDetails && seaConsumptionDetails.consumption ? seaConsumptionDetails.consumption : 0;
    const seaConsumption = sailingTime * seaConsumptionRate;
    const portConsumption = portConsumptionRate * portTime;
    const totalConsumption = seaConsumption + portConsumption;

    const bunkerExpense = bunkerPrice * totalConsumption;

    const totalVoyageDays = sailingTime + portTime;

    // 2. Other Expenses
    const vType1 = MODEL_VOYAGE.VTYPE_E;
    const miscellaneousRevenue1 = await getMiscellaneousRevenue(vType1, modelVoyages.expvestData);

    const totalExpense = bunkerExpense + portExpenses + tolls + miscellaneousRevenue1;
    console.log("Calculated total expense", { totalExpense })

    return {
        totalExpense,
        totalVoyageDays,
        startToEndJourney: costInfo
    }

}

const getReqFuelTypePrices = async (vesselJourney) =>{
    const reqFuelTypePrices = {}
    for (let i = 0; i <= NO_OF_FUEL_TYPES.COUNT; i++) {
        reqFuelTypePrices[vesselJourney[`bnkr_fuelType_${i}`]] = vesselJourney[`bnkr_price_${i}`];
    }
    return reqFuelTypePrices;
}

const getCargoCommissionDetails = async (cargoSequenceDetails, cargo1Seq, cargo2Seq) => {
    const cargo1Commission = cargoSequenceDetails.find(details => cargo1Seq === details.cargoSeq);
    const cargo2Commission = cargoSequenceDetails.find(details => cargo2Seq === details.cargoSeq);
    return {
        cargo1Commission: cargo1Commission && cargo1Commission.commission ? cargo1Commission.commission : 0,
        cargo2Commission: cargo2Commission && cargo2Commission.commission ? cargo2Commission.commission : 0
    }
}

const getMiscellaneousRevenue = async (vType, expvestDetails) => {
    let miscellaneousRevenue = 0;
    expvestDetails.forEach((data) => {
        if(data.vtype === vType){
            miscellaneousRevenue = miscellaneousRevenue + parseFloat(data.amount);
        }
    });
    return miscellaneousRevenue;
}
const getDaysDifference = (date1, date2) => {
    return Math.abs((new Date(date1) - new Date(date2)) / GLOBAL_FLEET.TIME_TO_DAY_CALCULATION);
};

module.exports = {
    initiateModelTCEUpdation
}