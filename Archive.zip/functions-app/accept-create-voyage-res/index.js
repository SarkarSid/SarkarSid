const { connectToDB } = require('./dbConfig');
const createVoyageLogs = require('../models/createVoyageLogs.model');
const { deleteDraftVoyage } = require("./create-voyage-res.repository");
require('dotenv').config();

module.exports = function (context, req) {
    //NOSONAR Cosmos DB Demo Deployment
    connectToDB().then(async () => {
        let { SequenceID, Status, Message } = req?.body;
        if (!SequenceID || !Status || !Message) {
            context.res = {
                status: 400,
                headers: { 'content-type': 'application/json' },
                body: { 'status': 400, 'message': 'Required Fields are missing', 'success': false }
            }
            context.done();
        } else {
            let res = await updateCreateVoyageResponse(req.body);
            if (res) {
                context.res = {
                    status: 200,
                    headers: { 'content-type': 'application/json' },
                    body: { 'status': 200, 'message': 'Success', 'success': true }
                }
                context.done();
            } else {
                context.res = {
                    status: 400,
                    headers: { 'content-type': 'application/json' },
                    body: { 'status': 400, 'message': 'Record Not Found', 'success': false }
                }
                context.done();
            }
        }
    }).catch(error => {
        console.error('Error while connection: ', error);
        context.res = {
            status: 400,
            headers: { 'content-type': 'application/json' },
            body: { 'status': 400, 'message': 'Connection Error - ' + error, 'success': false }
        }
        context.done();
    })
    async function updateCreateVoyageResponse(body) {
        try {
            const obj = { Status: body.Status, Message: body.Message, reponseReceivedAt: new Date() }
            let res = await createVoyageLogs.findOneAndUpdate({ SequenceID: body.SequenceID,isValid:true }, obj);
                    
            if(body.Status === 'SUCCESS' && res && res.vesVoy && res.userId) {
                await deleteDraftVoyage(res.vesVoy, res.userId);
            }
            return (res) ? true : false
        } catch (err) {
            context.log('Error while updating create voyage logs and draft voyages', err);
            return err
        }
    }

}
