
const  voyageDraft = require('../models/voyageDraft.model');

const deleteDraftVoyage = async (vesVoy, userId) => {
    return voyageDraft.findOneAndUpdate(
        {vesVoy, isDeleted: false,isValid: true}, 
        {  
            isDeleted: true,
            canceledBy: userId,
            canceledDate: new Date()
        }
        );
}

module.exports = {
    deleteDraftVoyage
}