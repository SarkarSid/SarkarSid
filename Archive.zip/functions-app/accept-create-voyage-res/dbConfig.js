const mongoose = require('mongoose');
require("dotenv").config();

mongoose.Promise = Promise;
mongoose.connection.on('connected', () => {
    console.log('Connection Established....')
})

mongoose.connection.on('reconnected', () => {
    console.log('Connection Reestablished....')
})

mongoose.connection.on('disconnected', () => {
    console.log('Connection Disconnected !')
    mongoose.connection.close().then(() => {
        console.log('Connection Closed Explicitly: ')
    }).catch((er) => {
        console.log('Connection Closed Explicitly: ', er)
    })
})

mongoose.connection.on('close', () => {
    console.log('Connection Closed.')
})

mongoose.connection.on('error', (error) => {
    console.log('ERROR: ' + error)
    mongoose.connection.close().then(() => {
        console.log('Connection Closed Explicitly: ')
    }).catch((er) => {
        console.log('Connection Closed Explicitly: ', er)
    })
})

const connectToDB = async () => {
    const url = "mongodb://" + process.env['BOOKING_SERVICE_CDB_HOST'] + ":" + process.env['BOOKING_SERVICE_CDB_PORT'] + "/" + process.env['BOOKING_SERVICE_CDB_DBNAME'] + "?ssl=true&replicaSet=globaldb";
    await mongoose.connect(url, {
        auth: {
            username: process.env['BOOKING_SERVICE_CDB_USERNAME'],
            password: process.env['BOOKING_SERVICE_CDB_PASSWORD']
        },
        useNewUrlParser: true,
        useUnifiedTopology: true,
        retryWrites: false,
    })
}

module.exports = { connectToDB };