# Vessel Allocation Application Function Apps - NodeJs Based Funcctions
# Package Build Trigger
# Function app with VS code
1. installed dotnet in system
2. azure tool in VS Code extension
3. install azure tool https://www.npmjs.com/package/azure-functions-core-tools (for windows install exe file and for linux use npm command line)
4. updated and created file in functions-app/local.settings.json
{
    "IsEncrypted": false,
    "Values": {
        "AzureWebJobsStorage": "",
        "FUNCTIONS_WORKER_RUNTIME": "node",
        "FUNCTIONS_EXTENSION_VERSION": "~4",
        "WEBSITE_NODE_DEFAULT_VERSION": "~16"
    }
}