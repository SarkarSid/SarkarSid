const mongoose = require('mongoose');

const utilizationTodaySchema = mongoose.Schema({
    totalRob: {
        type: Number,
        defaultValue: 0
    },
    totalDwt: {
        type: Number,
        defaultValue: 0
    },
    totalUtilization: {
        type: Number,
        defaultValue: 0
    },
    regionWiseUtilization: {
        type: Array,
        defaultValue:[]
    },
    createdAt: {
        type: Date,
        defaultValue:"",
        require: true
    },
    updatedAt: {
        type: Date,
        defaultValue:"",
        require: true
    }
}, { timestamps: true ,collection:'utilizationToday'});

module.exports = mongoose.model('utilizationToday', utilizationTodaySchema);