const mongoose = require('mongoose');

const voyageDraftSchema = mongoose.Schema({
    vslCode: {
        type: String,
        defaultValue: ""
    },
    voyNum: {
        type: Number,
        defaultValue: ""
    },
    lastVoyNum: {
        type: Number,
        defaultValue: ""
    },
    startDate: {
        type: Date,
        defaultValue: ""
    },
    lastLOB: {
        type: String,
        defaultValue: ""
    },
    lastPort: {
        type: String,
        defaultValue: ""
    },
    estimateID: {
        type: String,
        defaultValue: ""
    },
    region: {
        type: String,
        defaultValue: ""
    },
    scheduledLOB: {
        type: String,
        defaultValue: ""
    },
    vesVoy: {
        type: String,
        defaultValue: ""
    },
    nextVesVoy: {
        type: String,
        defaultValue: ""
    },
    modelVoyageTCE: {
        type: String,
        defaultValue: ""
    },
    lastUpdatedBy: {
        type: String,
        defaultValue: ""
    },
    lastUpdatedUserName: {
        type: String,
        defaultValue: ""
    },
    lastUpdatedDate: {
        type: Date,
        defaultValue: ""
    },
    canceledBy: {
        type: String,
        defaultValue: ""
    },
    canceledUserName: {
        type: String,
        defaultValue: ""
    },
    isDeleted: {
        type: Boolean,
        defaultValue: ""
    },
    canceledDate: {
        type: Date,
        defaultValue: ""
    },
    isValid: {
        type: Boolean,
        defaultValue:""
    },
}, {timestamps: true,collection: 'voyageDraft'});
module.exports = mongoose.model('voyageDraftSchema', voyageDraftSchema);