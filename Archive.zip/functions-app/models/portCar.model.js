const mongoose = require('mongoose');
const portCarSchema = mongoose.Schema({
    vsl_code : {
        type: String,
        defaultValue: ""
    },
    voyage : {
        type: Number,
        defaultValue: ""
    },
    seq_no : {
        type: Number,
        defaultValue: ""
    },
    berth_seq_no : {
        type: Number,
        defaultValue: ""
    },
    seq : {
        type: Number,
        defaultValue: ""
    },
    fixture_no : {
        type: String,
        defaultValue: ""
    },
    portNo : {
        type: Number,
        defaultValue: ""
    },
    func : {
        type: String,
        defaultValue: ""
    },
    qtyShip : {
        type: Number,
        defaultValue: ""
    },
    qtyBL : {
        type: Number,
        defaultValue: ""
    },
    lastupdate : {
        type: Date,
        defaultValue:""
    },
    tsCargoId : {
        type: Number,
        defaultValue: ""
    },
    tsPortNo : {
        type: Number,
        defaultValue: ""
    },
    tsFreight :  {
        type: Number,
        defaultValue: ""
    },
    cargoId : {
        type: Number,
        defaultValue: ""
    },
    vesVoy : {
        type: String,
        defaultValue: ""
    },
    fleet : {
        type: String,
        defaultValue: ""
    },
    __v : {
        type: Number,
        defaultValue: ""
    },
    fixtCargNo : {
        type: Number,
        defaultValue: ""
    },
    cargo_short : {
        type: String,
        defaultValue: ""
    },
    cpUnit : {
        type: String,
        defaultValue: ""
    },   
    ls_pdays : {
        type: Number,
        defaultValue: ""
    },
    orderNo : {
        type: String,
        defaultValue: ""
    }, 
    flags : {
        type: Number,
        defaultValue: ""
    },
    laycanFr : {
        type: String,
        defaultValue: ""
    },
    laycanTo : {
        type: String,
        defaultValue: ""
    },
    tuitinSeq : {
        type: Number,
        defaultValue: ""
    },
    minQty: {
        type: Number,
        defaultValue: ""
    },
    maxQty : {
        type: Number,
        defaultValue: ""
    },
    tsFrtType : {
        type: String,
        defaultValue: ""
    },
    ordNo : {
        type: Number,
        defaultValue: ""
    },
    _sqlid : {
        type: Number,
        defaultValue: ""
    },
    apiShip : {
        type: Number,
        defaultValue: ""
    },
    ld_rate : {
        type: Number,
        defaultValue: ""
    },
    terms : {
        type: String,
        defaultValue: ""
    },
    liftQty : {
        type: Number,
        defaultValue: ""
    },
    liftUnit : {
        type: String,
        defaultValue: ""
    },
    pexpCurr : {
        type: String,
        defaultValue: ""
    },
    pexpCurrAmount : {
        type: Number,
        defaultValue: ""
    },
    pexpExchangeRate : {
        type: Number,
        defaultValue: ""
    },
    xpDays : {
        type: Number,
        defaultValue: ""
    },
    entryDate : {
        type: String,
        defaultValue: ""
    },
    snapshotdatetimeUTC : {
        type: Date,
        defaultValue:""
    },
    tt_hrs : {
        type: Number,
        defaultValue: ""
    },
    Column_2 : {
        type: String,
        defaultValue: ""
    },
    ets : {
        type: String,
        defaultValue: ""
    },
    updateTimes : {
        type: Number,
        defaultValue: ""
    },
    altLiftQty : {
        type: Number,
        defaultValue: ""
    },
    altLiftUnit :{
        type: String,
        defaultValue: ""
    },
    blInfoRec : {
        type: String,
        defaultValue: ""
    },
    pumpingHrs :  {
        type: Number,
        defaultValue: ""
    },
    estimatedLDRate : {
        type: Number,
        defaultValue: ""
    },
    estimatedRateUnit : {
        type: String,
        defaultValue: ""
    },
    issueDate : {
        type: String,
        defaultValue: ""
    },
    blCode : {
        type: String,
        defaultValue: ""
    },
    lastuserid : {
        type: String,
        defaultValue: ""
    },
    pexp : {
        type: Number,
        defaultValue: ""
    },
    rateUnit : {
        type: String,
        defaultValue: ""
    },
    isDeleted : {
        type: Boolean,
        defaultValue: false
    },
    etl_update_date_UTC : {
        type: Date,
        defaultValue:""
    }
}, { collection: 'portcar' })
portCarSchema.index({ fleet: 1 });
module.exports = mongoose.model('portCarSchema', portCarSchema);