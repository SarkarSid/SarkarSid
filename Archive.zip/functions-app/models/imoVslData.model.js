const mongoose = require('mongoose');

const imoVslSchema = mongoose.Schema({
    vslName:{
        type:String,
        defaultValue:""
    },
    vslCode:{
        type:String,
        defaultValue:""
    },
    imoNumber:{
        type:String,
        defaultValue:""
    }
},{ timestamps: true });

module.exports = mongoose.model('imoVslData', imoVslSchema);