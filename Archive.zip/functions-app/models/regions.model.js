const mongoose = require('mongoose');

const regions = mongoose.Schema({
    sub_region_id: {
        type: String,
        defaultValue: ""
    },
    sub_region: {
        type: String,
        defaultValue: ""
    },
    parent_region: {
        type: String,
        defaultValue: ""
    },
    end_parent_region: {
        type: String,
        defaultValue: ""
    },
    LOB: {
        type: String,
        defaultValue: ""
    },
}, { timestamps: true });

module.exports = mongoose.model('regions', regions, 'regions');