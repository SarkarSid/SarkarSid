const mongoose = require('mongoose');

const lobWiseTCESchema = mongoose.Schema({
    lob: {
        type: String,
        defaultValue: "",
    },
    tcEquv: {
        type: Number,
        defaultValue: 0,
    },
    budget: {
        type: Number,
        defaultValue: 0,
    },
    TCEToday: {
        type: Number,
        defaultValue: 0,
    },
    budgetTCE: {
        type: Number,
        defaultValue: 0,
    },
    applicableDays: {
        type: Number,
        defaultValue: 0,
    },
    applicableProfit: {
        type: Number,
        defaultValue: 0,
    },
    applicableBudgetCont: {
        type: Number,
        defaultValue: 0,
    }
}, { _id : false });

const regionWiseTCESchema = mongoose.Schema({
    serviceArea: {
        type: String,
        defaultValue: "",
    },
    lobs: [lobWiseTCESchema],
    tcEquv: {
        type: Number,
        defaultValue: 0,
    },
    budget: {
        type: Number,
        defaultValue: 0,
    },
    TCEToday: {
        type: Number,
        defaultValue: 0,
    },
    budgetTCE: {
        type: Number,
        defaultValue: 0,
    },
    applicableDays: {
        type: Number,
        defaultValue: 0,
    },
    applicableProfit: {
        type: Number,
        defaultValue: 0,
    },
    applicableBudgetCont: {
        type: Number,
        defaultValue: 0,
    }
}, { _id : false });

const tceTodaySchema = mongoose.Schema({
    type: {
        type: String,
        defaultValue: "",
    },
    windowStartDate: {
        type: Date,
        defaultValue: ""
    },
    windowEndDate: {
        type: Date,
        defaultValue: ""
    },
    totalApplicableProfit: {
        type: Number,
        defaultValue: null
    },
    totalBudgetContribution: {
        type: Number,
        defaultValue: null
    },
    totalApplicableDays: {
        type: Number,
        defaultValue: null
    },
    totalTCEToday: {
        type: Number,
        defaultValue: null
    },
    totalBudgetTCE: {
        type: Number,
        defaultValue: null
    },
    actualCalculatedTCEToday: {
        type: Number,
        defaultValue: null
    },
    regions: [regionWiseTCESchema],
    createdAt: {
        type: Date,
        defaultValue: "",
        require: true
    },
    updatedAt: {
        type: Date,
        defaultValue: "",
        require: true
    }
}, { timestamps: true });
tceTodaySchema.index({ windowStartDate: -1 });


module.exports = mongoose.model('calculatedTceToday', tceTodaySchema, 'calculatedTceToday');