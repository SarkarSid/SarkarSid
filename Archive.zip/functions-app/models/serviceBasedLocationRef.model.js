const mongoose = require('mongoose');

const serviceBasedLocationRefes = mongoose.Schema({
    serviceArea: {
        type: String,
        defaultValue: ""
    },
    defaultLocationRefs: {
        type: Array,
        defaultValue: []
    },
    locationRefs: {
        type: Array,
        defaultValue: []
    },
}, { timestamps: true });

module.exports = mongoose.model('servicebasedlocationrefes', serviceBasedLocationRefes);