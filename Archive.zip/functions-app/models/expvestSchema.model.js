const mongoose = require('mongoose');

const expvestData = mongoose.Schema({
    snapshotdatetimeUTC:{
        type:Date,
        defaultValue:""
    },
    fleet:{
        type:String,
        defaultValue:""
    },
    _sqlid:{
        type:String,
        defaultValue:""
    },
    vsl_voy_id:{
        type:String,
        defaultValue:""
    },
    vtype:{
        type:String,
        defaultValue:""
    },
    cargo:{
        type:String,
        defaultValue:""
    },
    amount:{
        type:String,
        defaultValue:""
    },
    lastUpdate:{
        type:Date,
        defaultValue:""
    },
    seq:{
        type:String,
        defaultValue:""
    },
    vdesc:{
        type:String,
        defaultValue:""
    },
    entryDate:{
        type:Date,
        defaultValue:""
    },
    updateTimes:{
        type:String,
        defaultValue:""
    },
    blank0:{
        type:String,
        defaultValue:""
    },
    lastuserid:{
        type:String,
        defaultValue:""
    },
    curr:{
        type:String,
        defaultValue:""
    },
    base_equiv:{
        type:String,
        defaultValue:""
    },
    rate:{
        type:String,
        defaultValue:""
    },
    rateUnits:{
        type:String,
        defaultValue:""
    },
    billCode:{
        type:String,
        defaultValue:""
    },
    flags:{
        type:String,
        defaultValue:""
    },
    cargoSeq:{
        type:String,
        defaultValue:""
    },
    subCode:{
        type:String,
        defaultValue:""
    },
    portNo:{
        type:String,
        defaultValue:""
    },
    gradeSeq:{
        type:String,
        defaultValue:""
    },
    isDeleted: {
        type: Boolean,
        defaultValue: false
    }
    
}, { timestamps: true });

expvestData.index({ snapshotdatetimeUTC: -1 });
module.exports = mongoose.model('expvestData', expvestData);