const mongoose = require('mongoose');

const voyage = mongoose.Schema({
    snapshotdatetimeUTC: {
        type: Date,
        defaultValue: ""
    },
    fleet: {
        type: String,
        defaultValue: ""
    },
    vslCode: {
        type: String,
        defaultValue: ""
    },
    voyNum: {
        type: Number,
        defaultValue: ""
    },
    vslName: {
        type: String,
        defaultValue: "",
    },
    fixture_no: {
        type: String,
        defaultValue: "",
    },
    startingDateTime: {
        type: Date,
        defaultValue: ""
    },
    endingDateTime: {
        type: Date,
        defaultValue: "",
        index: true
    },
    oprType: {
        type: String,
        defaultValue: ""
    },
    oprCoordinator: {
        type: String,
        defaultValue: ""
    },
    last_update: {
        type: Date,
        defaultValue: ""
    },
    vesVoy: {
        type: String,
        defaultValue: ""
    },
    isDeleted: {
        type: Boolean,
        defaultValue: ""
    },
    lob: {
        type: String,
        defaultValue: ""
    },
    etl_update_date_UTC: {
        type: Date,
        defaultValue: ""
    },
    entry_date: {
        type: Date, 
        defaultValue: ""
    },
    completeGmt: {
        type: Date, 
        defaultValue: ""
    },
    commenceGmt: {
        type: Date, 
        defaultValue: ""
    }
},{collection : 'voyage'});
voyage.index({ endingDateTime: 1 });
voyage.index({ voyNum: 1 });
voyage.index({ vslCode: 1 });
voyage.index({ completeGmt: 1 });
voyage.index({ entry_date: -1 });

module.exports = mongoose.model('voyage', voyage);