const mongoose = require('mongoose');

const lobWiseSchema = mongoose.Schema({
    lob: {
        type: String,
        defaultValue: "",
    },
    capacity: {
        type: Number,
        defaultValue: 0,
    },
    rob: {
        type: Number,
        defaultValue: 0,
    },
    utilization: {
        type: Number,
        defaultValue: 0,
    }
}, { _id : false });

const regionWiseSchema = mongoose.Schema({
    serviceArea: {
        type: String,
        defaultValue: "",
    },
    lobs: [lobWiseSchema],
    capacity: {
        type: Number,
        defaultValue: 0,
    },
    rob: {
        type: Number,
        defaultValue: 0,
    },
    utilization: {
        type: Number,
        defaultValue: 0,
    },
}, { _id : false });

const calculatedCommercialUtilizationSchema = mongoose.Schema({
    windowStartDate: {
        type: Date,
        defaultValue: ""
    },
    windowEndDate: {
        type: Date,
        defaultValue: ""
    },
    totalCapacity: {
        type: Number,
        defaultValue: null
    },
    totalRob: {
        type: Number,
        defaultValue: null
    },
    totalUtilization: {
        type: Number,
        defaultValue: null
    },
    regions: {
        type: Object
    },
    
}, { timestamps: true });
calculatedCommercialUtilizationSchema.index({ windowStartDate: -1 });


module.exports = mongoose.model('calculatedCommercialUtilization', calculatedCommercialUtilizationSchema, 'calculatedCommercialUtilization');