const mongoose = require('mongoose');

const modelVoyage = mongoose.Schema({
    estimateId: {
        type: String,
        defaultValue: ""
    },
}, { timestamps: true });

module.exports = mongoose.model('modelVoyage', modelVoyage);