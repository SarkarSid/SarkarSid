const mongoose = require('mongoose');

const PnlSchema = mongoose.Schema({
    snapshotdatetimeUTC: {
        type: Date,
        defaultValue: ""
    },
    vslCode: {
        type: String,
        defaultValue: ""
    },
    voyNo: {
        type: Number,
        defaultValue: ""
    },
    tcEquv: {
        type: String,
        defaultValue: ""
    },
    data_type: {
        type: String,
        defaultValue: ""
    },
    entry_date: {
        type: Date,
        defaultValue: ""
    },
    snapshotType: {
        type: String,
        defaultValue: ""
    },
    snapshotRefDate: {
        type: Date,
        defaultValue: ""
    },
    oprCoordinator: {
        type: String,
        defaultValue: ""
    },
    commencingDate: {
        type: Date,
        defaultValue: ""
    },
    completedDate: {
        type: Date,
        defaultValue: ""
    },
    commencingGMT: {
        type: Date,
        defaultValue: ""
    },
    completedGMT: {
        type: Date,
        defaultValue: ""
    },
    tradeArea: {
        type: String,
        defaultValue: ""
    },
    vesVoy: {
        type: String,
        defaultValue: ""
    },
    vsl_type: {
        type: String,
        defaultValue: ""
    },
    vsl_class: {
        type: String,
        defaultValue: ""
    },
    voyageStatus: {
        type: String,
        defaultValue: ""
    },
    oprType: {
        type: String,
        defaultValue: ""
    }
}, { timestamps: true, collection: 'voyagepnl' });

module.exports = mongoose.model('voyagepnl', PnlSchema);