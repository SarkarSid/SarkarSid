const mongoose = require('mongoose');

const portConsumptionRate = mongoose.Schema(Object);

module.exports = mongoose.model('portConsumptionRate', portConsumptionRate);