const mongoose = require('mongoose');
const pastVoyageROB = mongoose.Schema({
    szVesselCode:{
        type: String,
        defaultValue: ""
    },
    fleet: {
        type: String,
        defaultValue: ""
    },
    idVoyageNumber: {
        type: Number,
        defaultValue: ""
    },
    fROB: {
        type: Number,
        defaultValue: ""
    },
    __v: {
        type: Number,
        defaultValue: ""
    },
    isDeleted: {
        type: Boolean,
        defaultValue:false
    },
    etl_update_date_UTC: {
        type: Date,
        defaultValue:""
    }
}, { collection: 'voyage_ROB' });

module.exports = mongoose.model('pastVoyageROB', pastVoyageROB);