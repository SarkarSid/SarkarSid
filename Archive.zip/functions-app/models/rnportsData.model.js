const mongoose = require('mongoose');

const rnportData = mongoose.Schema({
    snapshotdatetimeUTC:{
        type:Date,
        defaultValue:""
    },
    _sqlid:{
        type:Number,
        defaultValue:""
    },
    fleet:{
        type:String,
        defaultValue:""
    },
    no:{
        type:Number,
        defaultValue:""
    },
    vesid:{
        type:Number,
        defaultValue:""
    },
    country:{
        type:String,
        defaultValue:""
    },
    name:{
        type:String,
        defaultValue:""
    },
    lon:{
        type:Number,
        defaultValue:0
    },
    lat:{
        type:Number,
        defaultValue:0
    },
    timezonecode:{
        type:String,
        defaultValue:""
    },
    timeZone:{
        type:Number,
        defaultValue:""
    },
    unctad_code:{
        type:String,
        defaultValue:""
    },
    defaultLocationRef:{
        type:String,
        defaultValue:""
    },
    locationRef:{
        type:String,
        defaultValue:""
    },
    lastupdate:{
        type:Date,
        defaultValue:""
    },
    Longitude_parsed: {
        type:Number,
        defaultValue:0
    },
    Latitude_parsed: {
        type:Number,
        defaultValue:0
    },
    isDeleted: {
        type:Boolean,
        defaultValue: false
    },
    etl_update_date_UTC: {
        type:Date,
        defaultValue:""
    }
}, { collection : 'rnports', timestamps: true });
rnportData.index({ fleet: 1 });
rnportData.index({ name: 1 });
rnportData.index({ isDeleted: 1 });

module.exports = mongoose.model('rnports', rnportData);