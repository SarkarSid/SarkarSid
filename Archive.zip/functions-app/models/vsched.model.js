const mongoose = require('mongoose');

const vschedSchema = mongoose.Schema({
    snapshotdatetimeUTC: {
        type: Date,
        defaultValue: ""
    },
    ves_code: {
        type: String,
        defaultValue: ""
    },
    voy_no_int: {
        type: Number,
        defaultValue: ""
    },
    seq_no_int: {
        type: Number,
        defaultValue: ""
    },
    miles: {
        type: Number,
        defaultValue: ""
    },
    fixture_no: {
        type: String,
        defaultValue: ""
    },
    ord_no_int: {
        type: Number,
        defaultValue: ""
    },
    port_no: {
        type: Number,
        defaultValue: ""
    },
    port: {
        type: String,
        defaultValue: ""
    },
    spd: {
        type: String,
        defaultValue: ""
    },
    p_arr_date: {
        type: Date,
        defaultValue: ""
    },
    anchorage_delay: {
        type: Number,
        defaultValue: ""
    },
    total_laytime: {
        type: Number,
        defaultValue: ""
    },
    p_depart_date: {
        type: Date,
        defaultValue: ""
    },
    a_arr_date: {
        type: String,
        defaultValue: ""
    },
    a_depart_date: {
        type: String,
        defaultValue: ""
    },
    bnkr_fuelType_0: {
        type: String,
        defaultValue: ""
    },
    bnkr_rec_0: {
        type: Number,
        defaultValue: ""
    },
    bnkr_fuelType_1: {
        type: String,
        defaultValue: ""
    },
    bnkr_rec_1: {
        type: Number,
        defaultValue: ""
    },
    bnkr_fuelType_2: {
        type: String,
        defaultValue: ""
    },
    bnkr_rec_2: {
        type: Number,
        defaultValue: ""
    },
    bnkr_fuelType_3: {
        type: String,
        defaultValue: ""
    },
    bnkr_rec_3: {
        type: Number,
        defaultValue: ""
    },
    bnkr_fuelType_4: {
        type: String,
        defaultValue: ""
    },
    bnkr_rec_4: {
        type: Number,
        defaultValue: ""
    },
    bnkr_fuelType_5: {
        type: String,
        defaultValue: ""
    },
    bnkr_rec_5: {
        type: Number,
        defaultValue: ""
    },
    func: {
        type: String,
        defaultValue: ""
    },
    lastUpdate: {
        type: Date,
        defaultValue: ""
    },
    sea_days: {
        type: Number,
        defaultValue: ""
    },
    vesVoy: {
        type: String,
        defaultValue: ""
    },
    fleet: {
        type: String,
        defaultValue: ""
    },
    extra_sea_days: {
        type: Number,
        defaultValue: ""
    },
    weather_factor: {
        type: Number,
        defaultValue: ""
    },
    port_days: {
        type: Number,
        defaultValue: ""
    },
    Is_miles: {
        type: Number,
        defaultValue: ""
    },
    full_away_date: {
        type: String,
        defaultValue: ""
    },
    bnkr_arr_0: {
        type: Number,
        defaultValue: ""
    },
    bnkr_arr_1: {
        type: Number,
        defaultValue: ""
    },
    bnkr_arr_2: {
        type: Number,
        defaultValue: ""
    },
    bnkr_dep_0: {
        type: Number,
        defaultValue: ""
    },
    bnkr_dep_1: {
        type: Number,
        defaultValue: ""
    },
    bnkr_dep_2: {
        type: Number,
        defaultValue: ""
    },
    bnkr_price_0: {
        type: Number,
        defaultValue: ""
    },
    bnkr_price_1: {
        type: Number,
        defaultValue: ""
    },
    bnkr_price_2: {
        type: Number,
        defaultValue: ""
    },
    isDeleted: {
        type: Boolean,
        defaultValue: ""
    },
    etl_update_date_UTC: {
        type: Date,
        defaultValue: "",
        index: true
    },
    entryDate:{
        type: Date,
        defaultValue:""
    }
}, { collection: 'vsched' });
vschedSchema.index({ snapshotdatetimeUTC: -1 });
vschedSchema.index({ etl_update_date_UTC: -1 });
vschedSchema.index({ updatedAt: -1 });
vschedSchema.index({ voy_no_int: -1, ord_no_int: -1 });
vschedSchema.index({ ord_no_int: 1 });
vschedSchema.index({ ves_code: 1 });
vschedSchema.index({ voy_no_int: 1 });
vschedSchema.index({ fleet: 1 });
vschedSchema.index({ isDeleted: 1 });
vschedSchema.index({ spd: 1 });

module.exports = mongoose.model('vsched', vschedSchema);