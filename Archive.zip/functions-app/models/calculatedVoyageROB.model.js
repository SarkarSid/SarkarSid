const mongoose = require('mongoose');

const calculatedVoyageROBSchema = mongoose.Schema({
    vslCode: {
        type: String,
        defaultValue: "",
        require: true
    },
    voyNum: {
        type: Number,
        defaultValue: null,
        require: true
    },  
    vslCodeNum: {
        type: String,
        defaultValue: "",
        require: true
    },
    vslName: {
        type: String,
        defaultValue: "",
    },
    lob: {
        type: String,
        defaultValue: "",
        require: true
    },
    lastPortROB: {
        type: Number,
        defaultValue: null,
        require: true
    },
    lastPortUtilization: {
        type: Number,
        defaultValue: null,
        require: true
    },
    lastPortObj: {
        seq_no_int: {
            type: Number,
            defaultValue: null
        },
        ord_no_int: {
            type: Number,
            defaultValue: null
        },
        port_no: {
            type: Number,
            defaultValue: null
        },
        port: {
            type: String,
            defaultValue: ""
        },
    },
    qualifiedLegROB: {
        type: Number,
        defaultValue: null,
        require: true
    },
    qualifiedLegUtilization: {
        type: Number,
        defaultValue: null,
        require: true
    },
    qualifiedLegObj: {
        seq_no_int: {
            type: Number,
            defaultValue: null
        },
        ord_no_int: {
            type: Number,
            defaultValue: null
        },
        port_no: {
            type: Number,
            defaultValue: null
        },
        port: {
            type: String,
            defaultValue: ""
        },
    },
    createdAt: {
        type: Date,
        defaultValue: "",
        require: true
    },
    updatedAt: {
        type: Date,
        defaultValue: "",
        require: true
    }
}, { timestamps: true, collection: 'calculatedVoyageROB' });
calculatedVoyageROBSchema.index({ vslCode: 1, voyNum: 1 }, {unique: true});

module.exports = mongoose.model('calculatedVoyageROB', calculatedVoyageROBSchema);