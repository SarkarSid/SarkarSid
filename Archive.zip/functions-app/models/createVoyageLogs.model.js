const mongoose = require('mongoose');

const createVoyageLogs = mongoose.Schema({
    SequenceID: {
        type: Number,
        defaultValue: null,
        unique: true,
        require: true
    },
    EstimateID: {
        type: String,
        defaultValue: "",
        require: true
    },
    ActionType: {
        type: String,
        defaultValue: "",
        require: true
    },
    OpsCoordinator: {
        type: String,
        defaultValue: "",
        require: true
    },
    COACagro: {
        type: Number,
        defaultValue: null,
        require: true
    },
    SPOTCagro: {
        type: Number,
        defaultValue: null,
        require: true
    },
    User: {
        type: String,
        defaultValue: "",
        require: true
    },
    UserGroup: {
        type: String,
        defaultValue: "",
        require: true
    },
    Ship: {
        type: String,
        defaultValue: "",
        require: true
    },
    VoyageNum: {
        type: Number,
        defaultValue: null,
        require: false
    },
    CompanyName: {
        type: String,
        defaultValue: "",
        require: true
    },
    Status: {
        type: String,
        defaultValue: "PENDING",
        require: false
    },
    Message: {
        type: String,
        defaultValue: "",
        require: false
    },
    Exp: {},
    reponseReceivedAt: {
        type: Date,
        defaultValue:"",
        require: false
    },
    createdAt: {
        type: Date,
        defaultValue:"",
        require: true
    },
    updatedAt: {
        type: Date,
        defaultValue:"",
        require: true
    },
    vesVoy: {
        type: String,
        defaultValue: "",
        require: false
    },
    nextVesVoy: {
        type: String,
        defaultValue: "",
        require: false
    },
    viewSource: {
        type: String,
        defaultValue: "",
        require: false
    },
    lob: {
        type: String,
        defaultValue: "",
        require: false
    },
    serviceRegion: {
        type: String,
        defaultValue: "",
        require: true
    },
    startDate: {
        type: Date,
        defaultValue: "",
        require: false
    },
    userId: {
        type: String,
        defaultValue: "",
        require: false
    },
    isValid: {
        type: Boolean,
        defaultValue:""
    },
    createdByUserName: {
        type: String,
        defaultValue: "",
        require: false       
    }
}, { timestamps: true });

module.exports = mongoose.model('createVoyageLogs', createVoyageLogs);