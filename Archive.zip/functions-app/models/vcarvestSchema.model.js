const mongoose = require('mongoose');

const vcarvestSchema = mongoose.Schema({
    snapshotdatetimeUTC:{
        type: Date,
        defaultValue:""
    },
    cp_qty: {
        type: Number,
        defaultValue: ""
    },
    vsl_voy_id:{
        type: String,
        defaultValue:""
    },
    cargo: {
        type: String,
        defaultValue:""
    },
    freight: {
        type: Number,
        defaultValue:""
    },
    __v: {
        type: Number,
        defaultValue:""
    },
    cargoSeq: {
        type: Number,
        defaultValue:""
    },
    createdAt: {
        type: Date,
        defaultValue:""
    },
    updatedAt: {
        type: Date,
        defaultValue:""
    },
    fleet: {
        type: String,
        defaultValue: ""
    },
    _sqlid: {
        type: Number,
        defaultValue: ""
    },
    status: {
        type: String,
        defaultValue: ""
    },
    letter: {
        type: String,
        defaultValue: ""
    },
    charterer: {
        type: String,
        defaultValue: ""
    },
    api_sg: {
        type: String,
        defaultValue: ""
    },
    loadRate: {
        type: Number,
        defaultValue: ""
    },
    unit: {
        type: String,
        defaultValue: ""
    },
    laycan_fr: {
        type: Date,
        defaultValue: ""
    },
    laycan_to: {
        type: Date,
        defaultValue: ""
    },
    demurrage: {
        type: Number,
        defaultValue: ""
    },
    optionIndex: {
        type : Number,
        defaultValue: ""
    },
    demurrageLoad: {
        type : Number,
        defaultValue: ""
    },
    cargo_type: {
        type: String,
        defaultValue: ""
    },
    min_qty: {
        type : Number,
        defaultValue: ""
    },
    max_qty: {
        type: Number,
        defaultValue: ""
    },
    company: {
        type: String,
        defaultValue: ""
    },
    lob: {
        type: String,
        defaultValue: ""
    },
    vesselType: {
        type: String,
        defaultValue: ""
    },
    cp_form: {
        type: String,
        defaultValue: ""
    },
    flags: {
        type: Number,
        defaultValue: ""
    },
    lastUpdate: {
        type: Date,
        defaultValue: ""
    },
    isDeleted: {
        type: Boolean,
        defaultValue: ""
    },
    etl_update_date_UTC: {
        type: Date,
        defaultValue: ""
    }

},{ collection: 'vcarvest' });

module.exports = mongoose.model('vcarvestSchema', vcarvestSchema);
