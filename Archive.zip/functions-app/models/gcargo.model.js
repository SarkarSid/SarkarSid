const mongoose = require('mongoose');
const gcargoSchema = mongoose.Schema({
    snapshotdatetimeUTC : {
        type: Date,
        defaultValue:""
    },
    cargoId : {
        type: Number,
        defaultValue:""
    },
    cargo : {
        type: String,
        defaultValue:""
    },
    cpQty : {
        type: Number,
        defaultValue:""
    },
    cargoAssigned : {
        type: Number,
        defaultValue:""
    },
    charterer : {
        type: String,
        defaultValue:""
    },
    laycanFrom : {
        type: Date,
        defaultValue:""
    },
    laycanTo : {
        type: Date,
        defaultValue:""
    },
    fixture_no : {
        type: String,
        defaultValue:""
    },
    vslCode : {
        type: String,
        defaultValue:""
    },
    voyNo : {
        type: Number,
        defaultValue:""
    },
    loadRegion : {
        type: String,
        defaultValue:""
    },
    discRegion : {
        type: String,
        defaultValue:""
    },
    flag2 : {
        type: Number,
        defaultValue:""
    },
    lastUpdate : {
        type: Date,
        defaultValue:""
    },
    shipmentRef : {
        type: String,
        defaultValue:""
    },
    fleet : {
        type: String,
        defaultValue:""
    },
    vesVoy: {
        type: String,
        defaultValue:""
    },
    shipmentRef_fleet : {
        type: String,
        defaultValue:""
    },
    lob :  {
        type: String,
        defaultValue:""
    },
    __v :  {
        type: Number,
        defaultValue:""
    },
    _sqlid :  {
        type: Number,
        defaultValue:""
    },
    optionType :  {
        type: String,
        defaultValue:""
    },
    voption :  {
        type: Number,
        defaultValue:""
    },
    frtType :  {
        type: String,
        defaultValue:""
    },
    freight : {
        type: Number,
        defaultValue:""
    },
    lumpsum :  {
        type: Number,
        defaultValue:""
    },
    demurrage :  {
        type: Number,
        defaultValue:""
    },
    demurrageLoad :  {
        type: Number,
        defaultValue:""
    },
    contractType : {
        type: String,
        defaultValue:""
    },
    COANo : {
        type: String,
        defaultValue:""
    },
    vsl_voy_id : {
        type: String,
        defaultValue:""
    },
    coaId : {
        type: Number,
        defaultValue:""
    },
    salesContractId : {
        type: Number,
        defaultValue:""
    },
    remark : {
        type: String,
        defaultValue:""
    },
    cargoUnit : {
        type: String,
        defaultValue:""
    },
    api : {
        type: Number,
        defaultValue:""
    },
    useId :  {
        type: String,
        defaultValue:""
    },
    entryDate : {
        type: Number,
        defaultValue:""
    },
    updateTimes :  {
        type: Number,
        defaultValue:""
    },
    curr :  {
        type: String,
        defaultValue:""
    },
    exchgRate :  {
        type: Number,
        defaultValue:""
    },
    lastuserid :  {
        type: String,
        defaultValue:""
    },
    fixcSeq : {
        type: Number,
        defaultValue:""
    },
    estcSeq : {
        type: Number,
        defaultValue:""
    },
    flag1 : {
        type: Number,
        defaultValue:""
    },
    company : {
        type: String,
        defaultValue:""
    },
    externalRef : {
        type: String,
        defaultValue:""
    },
    coordinator : {
        type: String,
        defaultValue:""
    },
    stdRef1 : {
        type: String,
        defaultValue:""
    }, 
    stdRef2 : {
        type: String,
        defaultValue:""
    }, 
    stdRef3 : {
        type: String,
        defaultValue:""
    }, 
    stdRef4 : {
        type: String,
        defaultValue:""
    }, 
    vrouteCorrelation : {
        type: Number,
        defaultValue:""
    }, 
    min_qty : {
        type: Number,
        defaultValue:""
    }, 
    max_qty : {
        type: Number,
        defaultValue:""
    }, 
    cp_date : {
        type: String,
        defaultValue:""
    }, 
    cp_form : {
        type: String,
        defaultValue:""
    }, 
    demCurr : {
        type: String,
        defaultValue:""
    }, 
    currDemLoad : {
        type: Number,
        defaultValue:""
    },
    currDemDisc : {
        type: Number,
        defaultValue:""
    },
    demXRate : {
        type: Number,
        defaultValue:""
    },
    tradeAreaNo : {
        type: Number,
        defaultValue:""
    },
    vesselType :{
        type: String,
        defaultValue:""
    },
    paymentCompanyNo :{
        type: Number,
        defaultValue:""
    },
    paymentRemBankSeq : {
        type: Number,
        defaultValue:""
    },
    paytermsCode : {
        type: String,
        defaultValue:""
    },
    invoicePct :{
        type: Number,
        defaultValue:""
    },
    payTerms :{
        type: String,
        defaultValue:""
    },
    oblNum :{
        type: String,
        defaultValue:""
    },
    coMingle : {
        type: String,
        defaultValue:""
    },
    trader : {
        type: String,
        defaultValue:""
    },
    timeBarDays :{
        type: Number,
        defaultValue:""
    },
    balancePaytermsCode : {
        type: String,
        defaultValue:""
    },
    balancePaytermsDesc : {
        type: String,
        defaultValue:""
    },
    nomQty : {
        type: Number,
        defaultValue:""
    },
    emailSchedule : {
        type: String,
        defaultValue:""
    },
    emailInterval : {
        type: Number,
        defaultValue:""
    },
    baseCurr : {
        type: String,
        defaultValue:""
    },
    coaSeq :  {
        type: Number,
        defaultValue:""
    },
    cp_place :  {
        type: String,
        defaultValue:""
    },
    rebill_wharfage :  {
        type: String,
        defaultValue:""
    },
    rebill_dockage :  {
        type: String,
        defaultValue:""
    },
    invQty :  {
        type: Number,
        defaultValue:""
    },
    chartererType :  {
        type: String,
        defaultValue:""
    },
    fixFlags : {
        type: Number,
        defaultValue:""
    },
    confDate :  {
        type: String,
        defaultValue:""
    },
    contractRef :  {
        type: String,
        defaultValue:""
    },
    refTcCode :  {
        type: String,
        defaultValue:""
    },
    advPricingOverridenResults : {
        type: Number,
        defaultValue:""
    },
    entryUserID :  {
        type: String,
        defaultValue:""
    },
    isDeleted :  {
        type: Boolean,
        defaultValue: false
    },
    etl_update_date_UTC :  {
        type: Date,
        defaultValue:""
    }

}, { collection: 'gcargo' });

 module.exports = mongoose.model('gcargoSchema',gcargoSchema );