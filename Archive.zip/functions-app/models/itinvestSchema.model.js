const mongoose = require('mongoose');

const itinvestSchema = mongoose.Schema({
    snapshotdatetimeUTC:{
        type: Date,
        defaultValue:""
    },
    miles: {
        type: Number,
        defaultValue: ""
    },
    vsl_voy_id:{
        type: String,
        defaultValue:""
    },
    pdays: {
        type: Number,
        defaultValue:""
    },
    pexp: {
        type: Number,
        defaultValue:""
    },
    __v: {
        type: Number,
        defaultValue:""
    },
    num: {
        type: Number,
        defaultValue: ""
    },
    createdAt: {
        type: Date,
        defaultValue:""
    },
    updatedAt: {
        type: Date,
        defaultValue:""
    },
    fleet: {
        type:  String,
        defaultValue: ""
    },
    _sqlid: {
        type:  Number,
        defaultValue: ""
    },
    port: {
        type:  String,
        defaultValue: ""
    },
    func: {
        type:  String,
        defaultValue: ""
    },
    status: {
        type:  String,
        defaultValue: ""
    },
    berth: {
        type:  String,
        defaultValue: ""
    },
    cargo: {
        type: String,
        defaultValue: ""
    },
    qty: {
        type: Number,
        defaultValue: ""
    },
    terms: {
        type: String,
        defaultValue: ""
    },
    rate: {
        type: Number,
        defaultValue: ""
    },
    fact: {
        type: Number,
        defaultValue: ""
    },
    s_days: {
        type: Number,
        defaultValue: ""
    },
    xs_days: {
        type: Number,
        defaultValue: ""
    },
    port_num: {
        type: Number,
        defaultValue: ""
    },
    speed: {
        type: Number,
        defaultValue: ""
    },
    dwt: {
        type: Number,
        defaultValue: ""
    },  
    cargo_unit: {
        type: String,
        defaultValue: ""
    },
    cargo_type: {
        type: String,
        defaultValue: ""
    },
    cargoSeq: {
        type: Number,
        defaultValue: ""
    },
    xpdays: {
        type: Number,
        defaultValue: ""
    },
    lastUpdate: {
        type: Date,
        defaultValue: ""
    },
    isDeleted: {
        type: Boolean,
        defaultValue: ""
    },
    etl_update_date_UTC: {
        type: Date,
        defaultValue: ""
    }
},{ collection: 'itinvest' });
itinvestSchema.index({ snapshotdatetimeUTC: -1 });

module.exports = mongoose.model('itinvestSchema', itinvestSchema);