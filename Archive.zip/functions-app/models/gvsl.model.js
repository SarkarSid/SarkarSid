const mongoose = require('mongoose');

const gvslSchema = mongoose.Schema({
    fleet: {
        type: String,
        defaultValue: "",
        index:true
    },
    vsl_code: {
        type: String,
        defaultValue: "",
        index:true
    },
    _sqlid: {
        type: String,
        defaultValue: ""
    },
    vsl_name: {
        type: String,
        defaultValue: "",
    },
    vsl_type: {
        type: String,
        defaultValue: "",
    },
    vsl_class: {
        type: String,
        defaultValue: "",
    },
    cap1: {
        type: Number,
        defaultValue: "",
    },
    cap2: {
        type: Number,
        defaultValue: "",
    },
    yearBuilt: {
        type: Number,
        defaultValue: "",
    },
    company: {
        type: String,
        defaultValue: "",
    },
    snapshotdatetimeUTC: {
        type: Date,
        defaultValue: "",
    },
    imo_no: {
        type: String,
        defaultValue: "",
    },
    voyNum: {
        type: Number,
        defaultValue: ""
    },
    dwt: {
        type: Number,
        defaultValue: "",
    },
    last_update: {
        type: Date,
        defaultValue: "",
    },
    isDeleted: {
        type: Boolean,
        defaultValue: "",
    },
    etl_update_date_UTC: {
        type: Date,
        defaultValue: "",
    }
}, { collection: 'gvsl' });
gvslSchema.index({ fleet: 1 });
gvslSchema.index({ vsl_code: 1 });

module.exports = mongoose.model('gvsl', gvslSchema);