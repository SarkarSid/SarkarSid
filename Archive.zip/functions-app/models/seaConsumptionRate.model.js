const mongoose = require('mongoose');

const seaConsumptionRate = mongoose.Schema({
    vsl_type: {
        type: String,
        defaultValue: ""
    },
    per_speed_consumption: {
        type: [{
            speed: {
                type: Number,
                defaultValue: ""
            },
            consumption: {
                type: Number,
                defaultValue: ""
            }
        }],
        defaultValue: []
    }
}, { timestamps: true });

module.exports = mongoose.model('seaConsumptionRate', seaConsumptionRate);