const { DAYS_COUNT } = require('../common/common_constant');
const { successResponse } = require('../common/response');
const { connectToDB } = require('../db-connections/dbConfig');
require('dotenv').config();

const { initiateTCECalculation } = require('./tce-today.service');

module.exports = function (context, req) {
    connectToDB().then(async () => {
        const today = new Date().toISOString().split('T')[0];
        const currentDate = new Date(`${today}T00:00:00.000Z`);
        const endWindowDate = new Date(`${today}T00:00:00.000Z`);
        endWindowDate.setDate(currentDate.getDate() + DAYS_COUNT.TCE_CAL_DAYS);
        
        const response = await initiateTCECalculation(currentDate, endWindowDate);

        context.res = successResponse(response);
        context.log('TCE Today calculation executed successfully');
        context.done();
    }).catch(error => {
        context.log('TCE Today error: ', error);
        throw error;
    })
    
    

    
}
