const {
    getPnlDataRepo,
    updateTCETodayDataRepo,
    getPortsDataRepo,
    getServiceAreaByPortNameRepo
} = require("./tce-today.repository");
const _ = require("lodash");
const { MISC_EXPENSE, REGIONS_COUPLE_WITH, GLOBAL_FLEET } = require('./tce-today-constants.js');
const { TCE_TYPE } = require("../common/common_constant");

const initiateTCECalculation = async (start, end, historicalDate=null) => {
    const currentDate = start, endWindowDate = end, totalApplicableDays = [], totalApplicableProfitData = [], totalBudgetContData = [];
    const pnlData = await getPnlData(currentDate, endWindowDate);
    const regionWiseTCEData = await Promise.all(pnlData.map(async (pnl, i) => {
        const voyage = pnl?.voyage;
        if (voyage) {
            const offHireDays = ((pnl?.nomove?.reduce((prevOffHire, nextOffHire) => prevOffHire + (nextOffHire['hours'] || 0), 0)) / 24) || 0;
            const { applicableDays, proratedOffHireDays, proratedPeriod } = await getApplicableDays(currentDate, endWindowDate, pnl, offHireDays);
            if (applicableDays > 0) {
                const onhireDays = Number(applicableDays - proratedOffHireDays);
                const budget = calculateBudgetForVoyage(pnl) || 0;
                totalApplicableDays.push(onhireDays);
                const applicableProfit = pnl?.tcEquv * onhireDays;
                const applicableBudgetCont = budget * onhireDays;
                totalApplicableProfitData.push(applicableProfit);
                totalBudgetContData.push(applicableBudgetCont);                
                // voyage excel sheet data
                let regionwiseData = {
                    ship: voyage?.vslName,
                    vslCode: voyage?.vslCode,
                    vslType: pnl?.gvsl?.vsl_type || '',
                    voyNo: voyage?.voyNum,
                    lob: voyage?.lob,
                    serviceArea: pnl?.region?.parent_region,
                    tcEquv: pnl?.tcEquv,
                    budget,
                    applicableDays,
                    applicableProfit,
                    applicableBudgetCont,
                    commencingGMT: pnl.commencingGMT,
                    completedGMT: pnl.completedGMT,
                    "Prorated % in the period": proratedPeriod,
                    "OFF HIRE Days": offHireDays,
                    "Prorated Off-hire days": proratedOffHireDays,
                    "OnHire/actualApplicableDays": onhireDays
                };
                if (pnl?.region?.LOB.includes('TRAMP')) {
                    regionwiseData['serviceArea'] = await setServiceArea(voyage);
                }
                return regionwiseData || null;
            }
            return null;
        }
    }));
    return await createTCECalculationResponse(currentDate, endWindowDate, historicalDate, { totalApplicableProfitData, totalBudgetContData, totalApplicableDays, regionWiseTCEData });
}

const createTCECalculationResponse = async (startDate, endDate, historicalDate, data={}) => {
    // Calculate total of applicable days, applicable profit/contribution, and total TCE today 
    const totalApplicableProfit = data.totalApplicableProfitData.reduce((sum, num) => sum + num);
    const totalBudgetContribution = data.totalBudgetContData.reduce((sum, num) => sum + num);
    const totalApplicableDay = data.totalApplicableDays.reduce((sum, num) => sum + num);
    const totalTCEToday = totalApplicableProfit / totalApplicableDay;
    const totalBudgetTCE = totalBudgetContribution / totalApplicableDay;
    // Calculate regionwise calculation with TCE today 
    const finalRegionWiseTCEData = await calculateSumOfValues(data.regionWiseTCEData);
    const calculatedTCEToday = {
        type: TCE_TYPE.TCE_TODAY_AND_BUDGET_TCE,
        windowStartDate: startDate,
        windowEndDate: endDate,
        totalApplicableDays: totalApplicableDay,
        totalApplicableProfit,
        totalBudgetContribution,
        totalTCEToday,
        totalBudgetTCE,
        actualCalculatedTCEToday: totalTCEToday - (Number(process.env['TCE_TODAY_MISC_EXPENSE']) || MISC_EXPENSE.AMOUNT),
        miscExpense: Number(process.env['TCE_TODAY_MISC_EXPENSE']) || MISC_EXPENSE.AMOUNT,
        regions: performTceCalOverCombinedRegions(finalRegionWiseTCEData)
    };
    await updateTCETodayData(calculatedTCEToday, historicalDate);
    return calculatedTCEToday; // replace this with "data.regionWiseTCEData" for getting all apllicable voyage list
}

const performTceCalOverCombinedRegions = (finalRegionWiseTCEData) => {
    try {
        return [
            ...finalRegionWiseTCEData,
            ...REGIONS_COUPLE_WITH.map((m) => ({
                serviceArea: m.name,
                regions: finalRegionWiseTCEData.filter((f) => m.coupleWith.includes(f.serviceArea))
            }))
                .map((m) => ({
                    serviceArea: m.serviceArea,
                    tcEquv: _.sumBy(m.regions, "tcEquv"),
                    budget: _.sumBy(m.regions, 'budget'),
                    applicableDays: _.sumBy(m.regions, "applicableDays"),
                    applicableProfit: _.sumBy(m.regions, "applicableProfit"),
                    applicableBudgetCont: _.sumBy(m.regions, 'applicableBudgetCont'),
                    lobs: _(_.flatMap(m.regions, (item) => item.lobs)).groupBy('lob')
                        .map((lobGroup, lob) => ({
                            lob: lob,
                            tcEquv: _.sumBy(lobGroup, 'tcEquv'),
                            budget: _.sumBy(lobGroup, 'budget'),
                            applicableDays: _.sumBy(lobGroup, 'applicableDays'),
                            applicableProfit: _.sumBy(lobGroup, 'applicableProfit'),
                            applicableBudgetCont: _.sumBy(lobGroup, 'applicableBudgetCont'),
                        }))
                        .map((data) => { 
                            data.TCEToday = data.applicableProfit / data.applicableDays;
                            data.budgetTCE = data.applicableBudgetCont / data.applicableDays;
                            return data;
                        })
                        .value()
                }))
                .map((data) => {
                    data.TCEToday = data.applicableProfit / data.applicableDays;
                    data.budgetTCE = data.applicableBudgetCont / data.applicableDays;
                    return data;
                }),
        ];
    } catch (error) {
        console.log('performTceCalOverCombinedRegions', error);
        throw error;
    }
}

const calculateSumOfValues = async (regionWiseTCEData) => {
    try {
        return _(regionWiseTCEData.filter((i) => i !== null && typeof i !== 'undefined'))
            .groupBy('serviceArea')
            .map((serviceArea, id) => ({
                serviceArea: id,
                tcEquv: _.sumBy(serviceArea, 'tcEquv'),
                budget: _.sumBy(serviceArea, 'budget'),
                applicableDays: _.sumBy(serviceArea, 'OnHire/actualApplicableDays'),
                applicableProfit: _.sumBy(serviceArea, 'applicableProfit'),
                applicableBudgetCont: _.sumBy(serviceArea, 'applicableBudgetCont'),
                lobs: calculateLobWiseTCEData(serviceArea)
            }))
            .map((data) => { 
                data.TCEToday = data.applicableProfit / data.applicableDays;
                data.budgetTCE = data.applicableBudgetCont / data.applicableDays;
                return data; 
            })
            .value();
    } catch (error) {
        console.log('calculateSumOfValues', error);
        throw error;
    }
}

const calculateLobWiseTCEData = (regionData) => {
    try {
        return _(regionData.filter((i) => i !== null && typeof i !== 'undefined'))
            .groupBy((item) => (item.lob.includes('TRAMP') ? 'TRAMP' : item.lob))
            .map((lob, id) => ({
                lob: id,
                tcEquv: _.sumBy(lob, 'tcEquv'),
                budget: _.sumBy(lob, 'budget'),
                applicableDays: _.sumBy(lob, 'OnHire/actualApplicableDays'),
                applicableProfit: _.sumBy(lob, 'applicableProfit'),
                applicableBudgetCont: _.sumBy(lob, 'applicableBudgetCont'),
            }))
            .map((data) => { 
                data.TCEToday = data.applicableProfit / data.applicableDays;
                data.budgetTCE = data.applicableBudgetCont / data.applicableDays;
                return data;
            })
            .value();
    } catch (error) {
        console.log('calculateLobWiseTCEData', error);
        throw error;
    }
}

const calculateBudgetForVoyage = (pnl) => {
    try {
        const budgetmatrix = pnl?.budgetmatrix;
        if (budgetmatrix?.length) {
            if (budgetmatrix?.length === 1) {
                return budgetmatrix[0].budget;
            } else {
                const sortedBudgetMatrix = _.sortBy(budgetmatrix, ['period_start_date']);
                return ( getDaysDifference(sortedBudgetMatrix[1].period_start_date, pnl.commencingGMT) * sortedBudgetMatrix[0].budget
                    + getDaysDifference(pnl.completedGMT, sortedBudgetMatrix[1].period_start_date) * sortedBudgetMatrix[1].budget
                ) / getDaysDifference(pnl.completedGMT, pnl.commencingGMT);
            }
        } else {
            return 0;
        }
    } catch (error) {
        console.log(err);
        return 0;
    }
}

const getPnlData = async (startWindowDate, endWindowDate) => {
    try {
        const pnlList = await getPnlDataRepo(startWindowDate, endWindowDate);
        return pnlList || [];
    } catch (err) {
        console.log(err);
        throw err;
    }
}

const getApplicableDays = (startDate, endDate, pnlData, offHireDays = 0) => {
    // Calculate min date and max date compare to window date 
    let minDates = [startDate, new Date(pnlData.commencingGMT)];
    let maxDates = [endDate, new Date(pnlData.completedGMT)];
    let endMinDate = new Date(Math.min.apply(null, maxDates));
    let startMaxDate = new Date(Math.max.apply(null, minDates));
    // Calculate applicable days 
    const days = getDaysDifference(endMinDate, startMaxDate);
    // Calculate Prorated % in the period 
    if (days > 0) {
        const proratedPeriod = days/getDaysDifference(pnlData.completedGMT, pnlData.commencingGMT)*100;
        // Calculate Prorated Off-hire days
        const proratedOffHireDays = offHireDays * proratedPeriod / 100;
        return { applicableDays: days || 0, proratedOffHireDays, proratedPeriod };
    }
    return { applicableDays: days || 0, proratedOffHireDays: 0, proratedPeriod: 0 };
}

const setServiceArea = async (voyage) => {
    try {
        const [portsData] = await getPortsDataRepo(voyage.vslCode, voyage.voyNum);
        if (typeof portsData !== 'undefined' && portsData.port !== null) {
            const startPort = portsData.port;
            const serviceRegion = await getServiceAreaByPort(startPort);
            return serviceRegion;
        }
    } catch (err) {
        console.log(err);
        throw err;
    }
}

const updateTCETodayData = async (obj, historicalDate) => {
    try {
        const curdate = historicalDate ? new Date(historicalDate).toISOString(): new Date().toISOString();
        const currentDate = curdate.split('T')[0];
        return updateTCETodayDataRepo(obj, currentDate);
    } catch (err) {
        console.log(err);
        throw err;
    }
}

const getServiceAreaByPort = async (port) => {
    try {
        let serviceArea = null;
        const [portData] = await getServiceAreaByPortNameRepo(port.toUpperCase());
        if (portData) {
            const { defaultLocationRef, locationRef } = portData;
            const [defaultLocationRefData] = defaultLocationRef;
            const [locationRefData] = locationRef;
            if (defaultLocationRefData && defaultLocationRefData.serviceArea) {
                serviceArea = defaultLocationRefData.serviceArea;
            } else if (locationRefData && locationRefData.serviceArea) {
                serviceArea = locationRefData.serviceArea;
            }
        }
        return serviceArea;
    } catch (err) {
        console.log(err)
        throw err;
    }
}

const getDaysDifference = (date1, date2) => {
    return Math.abs((new Date(date1) - new Date(date2)) / GLOBAL_FLEET.TIME_TO_DAY_CALCULATION);
};

module.exports = {
    initiateTCECalculation,
    getPnlData,
    getApplicableDays,
    setServiceArea,
    updateTCETodayData
}