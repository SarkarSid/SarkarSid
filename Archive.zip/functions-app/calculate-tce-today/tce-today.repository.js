const Voyage = require('../models/voyageVsl.model');
const VoyPnl = require('../models/pnl.model');
const vsched = require('../models/vsched.model');
const rnPorts = require("../models/rnportsData.model");
const tceTodaySchema = require("../models/tceToday.model");
const { GLOBAL_FLEET, OPR_TYPE, EXCLUDE_LOB, TCE_ACTIVITY } = require('./tce-today-constants.js');


const getPnlDataRepo = (startWindowDate, endWindowDate) => {
    return VoyPnl.aggregate([
        {
            $match: {
                $or: [
                    { $and: [{ commencingGMT: { $lte: startWindowDate } }, { completedGMT: { $gte: startWindowDate } }] },
                    { $and: [{ commencingGMT: { $lte: endWindowDate } }, { completedGMT: { $gte: endWindowDate } }] },
                    { $and: [{ commencingGMT: { $gte: startWindowDate } }, { completedGMT: { $lte: endWindowDate } }] },
                    { $and: [{ commencingGMT: { $lte: startWindowDate } }, { completedGMT: { $gte: endWindowDate } }] },
                ],
            }
        },
        {
            $group: {
                _id: {
                    vslCode: "$vslCode",
                    voyNo: "$voyNo",
                    vesVoy: "$vesVoy",
                    tcEquv: "$tcEquv",
                    commencingGMT: "$commencingGMT",
                    completedGMT: "$completedGMT"
                }
            }
        },
        {
            $project: {
                _id: 0,
                vslCode: "$_id.vslCode",
                voyNo: "$_id.voyNo",
                vesVoy: "$_id.vesVoy",
                tcEquv: { $toDouble: "$_id.tcEquv" },
                commencingGMT: "$_id.commencingGMT",
                completedGMT: "$_id.completedGMT",
            }
        },
        {
            $lookup: {
                from: "voyage",
                localField: "vesVoy",
                foreignField: "vesVoy",
                as: "voyage",
            },
        },
        {
            $match: {
                "voyage.oprType": OPR_TYPE.TCOV,
                "voyage.lob": { $not: { $regex: EXCLUDE_LOB.DDD } },
                "voyage.isDeleted": false
            }
        },
        { $unwind: "$voyage" },
        {
            $lookup: {
                from: "NoonMov1",
                localField: "vesVoy",
                foreignField: "vesVoy",
                as: "nomove",
            },
        },
        {
            $addFields: {
                nomove: {
                $filter: {
                  input: "$nomove",
                  as: "nomove",
                  cond: {
                    $and: [
                        { $eq: ["$$nomove.activity", TCE_ACTIVITY.OFF_HIRE] },
                        { $eq: ["$$nomove.isDeleted", false] } 
                    ]}
                }
              }
            },
        },
        {
            $lookup: {
                from: "regions",
                localField: "voyage.lob",
                foreignField: "LOB",
                as: "region",
            },
        },
        { $unwind: "$region" },
        {
            $lookup: {
                from: "gvsl",
                localField: "vslCode",
                foreignField: "vsl_code",
                as: "gvsl",
            },
        },
        {
            $addFields: {
                gvsl: {
                $filter: {
                  input: "$gvsl",
                  as: "gvsl",
                  cond: {
                    $and: [
                        { $eq: ["$$gvsl.fleet", GLOBAL_FLEET.STJS] },
                        { $eq: ["$$gvsl.isDeleted", false] } 
                    ]}
                }
              }
            },
        },
        { $unwind: { path: '$gvsl', preserveNullAndEmptyArrays: true} },
        {
            $lookup: {
                from: "budgettcematrixes",
                localField: "voyage.lob",
                foreignField: "LOB",
                as: "budgetmatrix",
            },
        },
        {
            $addFields: {
                budgetmatrix: {
                $filter: {
                  input: "$budgetmatrix",
                  as: "budget",
                  cond: { $eq: ["$$budget.vsl_type", "$gvsl.vsl_type"] }
                }
              }
            },
        },
        { $unwind: { path: '$budgetmatrix', preserveNullAndEmptyArrays: true } },
        {
            $addFields: {
                budgetmatrix: {
                    $cond: {
                        if: { $and: [ { $ifNull: ["$budgetmatrix", false] } ] },
                        then: {
                            $filter: {
                                input: "$budgetmatrix.budgets",
                                as: "budget",
                                cond: {
                                    $or: [
                                        {
                                            $and: [
                                                { $lte: [new Date("$budgetmatrix.period_start_date"), new Date("$commencingGMT")] },
                                                { $gte: [new Date("$budgetmatrix.period_end_date"), new Date("$completedGMT")] }
                                            ]
                                        },
                                        {
                                            $and: [
                                                { $gte: [new Date("$budgetmatrix.period_start_date"), new Date("$commencingGMT")] },
                                                { $gte: [new Date("$budgetmatrix.period_end_date"), new Date("$completedGMT")] }
                                            ]
                                        },
                                        {
                                            $and: [
                                                { $lte: [new Date("$budgetmatrix.period_start_date"), new Date("$commencingGMT")] },
                                                { $lte: [new Date("$budgetmatrix.period_end_date"), new Date("$completedGMT")] }
                                            ]
                                        }
                                    ],
                                }
                            }
                        },
                        else: []
                    }
                }
            },
        }
    ]);
}

const getPortsDataRepo = (vslCode, voyNum) => {
        return vsched.find({
            ves_code: vslCode,
            voy_no_int: voyNum,
            fleet: GLOBAL_FLEET.STJS,
            isDeleted: false
        }).sort({ ord_no_int: 1 }).limit(1);
}

const getServiceAreaByPortNameRepo = async (portName) => {
    return rnPorts.aggregate([
        {
            $match: {
                name: portName, fleet: GLOBAL_FLEET.STJS, isDeleted: false
            }
        },
        {
            $lookup: { from: 'servicebasedlocationrefes', localField: 'defaultLocationRef', foreignField: 'defaultLocationRefs', as: 'defaultLocationRef' }
        },
        {
            $lookup: { from: 'servicebasedlocationrefes', localField: 'locationRef', foreignField: 'locationRefs', as: 'locationRef' }
        }
    ]);
}

const updateTCETodayDataRepo = (obj, currentDate) => {
    return tceTodaySchema.findOneAndUpdate({
        windowStartDate: new Date(currentDate)
    }, obj, { upsert: true, new: true });
}

module.exports = {
    getPnlDataRepo,
    getPortsDataRepo,
    updateTCETodayDataRepo,
    getServiceAreaByPortNameRepo
}


