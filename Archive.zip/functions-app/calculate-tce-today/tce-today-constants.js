module.exports.GLOBAL_FLEET = {
    STJS: 'STJS',
    TIME_TO_DAY_CALCULATION: (36e5 * 24) // original value - (60*60*1000) * 24
}

module.exports.MISC_EXPENSE = {
    AMOUNT: 200
}

module.exports.OPR_TYPE = {
    TCOV: 'TCOV',
    TCTO: 'TCTO'
}

module.exports.EXCLUDE_LOB = {
    DDD: 'DDD',
}

module.exports.TCE_ACTIVITY = {
  OFF_HIRE: 'OFF HIRE'
}

module.exports.REGIONS_COUPLE_WITH = [
    {
      name: "Cont. EU & Med",
      coupleWith: ["Continental Europe", "Mediterranean"],
    },
    {
      name: "Americas",
      coupleWith: ["North America", "South America"],
    },
  ];