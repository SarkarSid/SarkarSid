module.exports.successResponse = (res) => {
    return {
        status: 200,
        headers: { 'content-type': 'application/json' },
        body: {
            success: true,
            ...res
        }
    };
};

module.exports.successResponseWithData = (res) => {
    return {
        status: 200,
        headers: { 'content-type': 'application/json' },
        body: {
            success: true,
            data:res
        }
    };
};

module.exports.errorResponse = (res, status=400) => {
    return {
        status: status,
        headers: { 'content-type': 'application/json' },
        body: {
            success: false,
            ...res
        }
    };
};