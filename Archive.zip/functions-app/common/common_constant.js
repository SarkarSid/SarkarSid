module.exports.GLOBAL_FLEET = {
    STJS: 'STJS',
    TIME_TO_DAY_CALCULATION: (36e5 * 24) // original value - (60*60*1000) * 24
}

module.exports.OPR_TYPE = {
	TCOV: 'TCOV',
    TCTO: 'TCTO'
};

module.exports.TCE_TYPE = {
	TCE_TODAY_AND_BUDGET_TCE: 'TCE_TODAY_AND_BUDGET_TCE',
    TCE_FLEET: 'TCE-FLEET',
    TCE_YTD: 'YTD-TCE'
};

module.exports.DAYS_COUNT = {
    ROLLING_TCE_DAYS: 90,
    TCE_CAL_DAYS: 60,
    UTILIZATION_DAYS: 60
}

module.exports.MODEL_VOYAGE = {
    SHIP_CAPACITY_MULTIPLIER: 0.95,
    ESTIMATE_ID_CONSTANT: 'ALLOC',
    VTYPE_R: 'R',
    VTYPE_E: 'E',
    SAILING_SPEED: 12.75,
    SEA_CONSUMPTION_SPEED: 12.5
}

module.exports.NO_OF_FUEL_TYPES = {
    COUNT: 2
}

module.exports.PERCENTAGE_OF_FUELS = {
    MGO: 0.2,
    LSF_IFO: 0.8
}

module.exports.SHIP_TYPE = {
    VE_COA: 'VE-COA',
    VE_SPOT: 'VE-SPOT'
}

module.exports.FUNCION_VALUES = {
    FUNCTION_M: 'M',
    FUNCTION_L: 'L',
    FUNCTION_D: 'D',
    FUNCTION_I: 'I'
};

module.exports.CREATE_VOYAGE_REQUEST_STATUS = {
    ERROR: 'ERROR',
    PENDING: 'PENDING',
    SUCCESS: 'SUCCESS'
}