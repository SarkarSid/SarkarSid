const { connectToDB } = require('../db-connections/dbConfig');
require('dotenv').config();
const calculateUtilizationService = require('../calculate-commercial-utilization/utilization.service.js');
const { DAYS_COUNT } = require('../common/common_constant');
const { successResponseWithData } = require('../common/response');

module.exports = function (context, req) {
    connectToDB().then(async () => {
        const today = new Date().toISOString().split('T')[0];
        const endDate = new Date(`${today}T00:00:00.000Z`);
        const startDate = new Date(`${today}T00:00:00.000Z`);
        let days_count = DAYS_COUNT.UTILIZATION_DAYS;
        if(req.body?.days && parseInt(req.body.days) > 0 && parseInt(req.body.days) <= 365){
            days_count = req.body.days;
        }
        startDate.setDate(endDate.getDate() - days_count);   
        
        const response = await calculateUtilizationService.initiateUtilizationCalculation(startDate, endDate, exportCheck = 'exportData');
        context.res = successResponseWithData(response);
        context.log('Utilization calculation executed successfully');
        context.done();
    }).catch(error => {
        context.log('Utilization error: ', error);
        throw error;
    })
}