var Connection = require('tedious').Connection;
var Request = require('tedious').Request;
var TYPES = require('tedious').TYPES;
const { connectToDB } = require('./dbConfig');
const pnl = require('../models/pnl.model');
const VoyageVsl = require('../models/voyageVsl.model');
require('dotenv').config();
const prefix = (process.env.SQL_DB_SCHEMA !== 'stg' ? 'dbo' : 'stg');

module.exports = function (context, req) {
    const stgConfig = {
        server: process.env.SQL_DB_HOST,
        authentication: {
            type: 'default',
            options: {
                userName: process.env.SQL_DB_USER,
                password: process.env.SQL_DB_PASSWORD
            },

        },
        options: {
            encrypt: true,
            trustServerCertificate: false,
            database: process.env.SQL_DB_DBNAME,
            port: 1433,
            requestTimeout: 500000

        }
    };
    //Cosmos DB
    connectToDB().catch(error => {
        console.error('Error while connection: ', error);
    })
    //STG connection
    const stg_connection_dest = new Connection(stgConfig);
    stg_connection_dest.on('connect', async function (err) {
        if (err) {
            context.log("err", err);
            context.done();
        } else {
            context.log("STG SQL connected.......");
            await initStgExecution();
        }
    }).connect();

async function initStgExecution(){
    try{
        const uniqueVoyagesList = await getUniqueVoyagesList();
        let whereStr = '';
        uniqueVoyagesList.map((el)=>{
            whereStr += `(vslCode = '${el._id.vslCode}' and voyNo = ${el._id.voyNum} and data_type = 'A') OR `   
        })
        const where = whereStr.slice(0, -3)
        const voyPnlData = await getAllVoyPnlData(prefix,where)
        if(voyPnlData.results.length){
            for (let i = 0; i < voyPnlData.results.length; i++){
                voyPnlData.results[i].vesVoy = voyPnlData.results[i].vslCode+'__'+voyPnlData.results[i].voyNo+'__'+voyPnlData.results[i].fleet;
                await pnl.findOneAndUpdate({vslCode : voyPnlData.results[i].vslCode, voyNo : voyPnlData.results[i].voyNo}, voyPnlData.results[i], {upsert: true, new: true});
            }
        }
        stg_connection_dest.close();
        context.log("STG SQL Connection Closed.......")
        context.done();
    } catch(err){
        stg_connection_dest.close();
        context.log("STG SQL Connection Closed catch.......")
        context.done();
    }
}
async function getUniqueVoyagesList() {
    try {
        const result = await VoyageVsl.aggregate([
            {$match : {isDeleted : false}},
            {$group : {_id : {vslCode:"$vslCode",voyNum:"$voyNum"}}},
            {$sort:{'_id.vslCode':1,'_id.voyNum':1}}
        ])
        return result
    } catch (err) {
        context.log(err)
        return err
    }
}
async function getAllVoyPnlData(dbName,where) {
    return new Promise(async (resolve, reject) => {
        try {
            let results = [];
            
            const schemaName = (dbName === 'stg' ? 'stg.voypnl_latest_v2': 'dbo.voypnl_latest_v2');
            let sqlQry = `SELECT TOP 1 WITH TIES
            snapshotdatetimeUTC,vslCode,voyNo,tcEquv,data_type,entry_date,snapshotType,snapshotRefDate,oprCoordinator,commencingDate,completedDate,commencingGMT,completedGMT,tradeArea,fleet, vsl_type, vsl_class, voyageStatus, oprType
          FROM ${schemaName} where ${where}
          ORDER BY ROW_NUMBER() OVER (PARTITION BY vslCode,voyNo ORDER BY entry_date DESC)`;
            const request = new Request(sqlQry, async (err, rows) => {
                if (err) {
                    context.log(err)
                    context.log(err.message);
                    reject(err.message)
                } else {
                    resolve({ results })
                }
            })
            request.on("row", columns => {
                const row = {}
                columns.forEach(column => {
                    row[column.metadata.colName] = column.value
                });
                results.push(row)
            });
            stg_connection_dest.execSql(request);
        } catch (err) {
            context.log(err)
        }
    });
}

}
