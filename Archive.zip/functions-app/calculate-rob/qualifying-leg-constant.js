module.exports.QUALIFYING_LEG_LIST = {
    "HBR-U": {
        "case": "DEPARTING_PORT",
        "portNo": [20128, 24040]
    },
    "ANZ": {
        "case": "FIRST_LEG_ARRIVAL_PORT",
        "portNo": [24040]

    },
    "TPW": {
        "case": "FIRST_LEG_ARRIVAL_PORT",
        "portNo": [24040]
    },
    "TRAMP": {
        "case": "HIGH_UTILISATION"
    },
    "BAJ": {
        "case": "LEG_WITH_MAX_DISTANCE"
    },
    "JAB": {
        "case": "LEG_WITH_MAX_DISTANCE"
    },
    "LAS-EN": {
        "case": "LEG_WITH_MAX_DISTANCE"
    },
    "AGE": {
        "case": "LEG_WITH_MAX_DISTANCE"
    },
    "HBR-C": {
        "case": "LEG_WITH_MAX_DISTANCE"
    },
    "SAS": {
        "case": "FIRST_LEG_DEPARTURE",
        "portName": "SOUTH AFRICA"
    },
    "GIR-U": {
        "case": "DEPARTING_PORT",
        "portNo": [20128]
    },
    "EXP-A": {
        "case": "FIRST_LEG_ARRIVAL",
        "country": ["INDIA", "PAKISTAN"]
    },
    "GIR-C" : {
        "case": "FIRST_LEG_ARRIVAL_PORT",
        "portNo": [20128]
    },
    "PACS" : {
        "case": "FIRST_LEG_ARRIVAL_PORT",
        "portNo": [20128]
    },
    "TAE" : {
        "case": "LAST_LEG_DEPARTURE",
        "country": "UNITED STATES"
    },
    "UMR-E" : {
        "case": "LAST_LEG_DEPARTURE",
        "country": "UNITED STATES"
    },
    "LAS-ES" : {
        "case": "LAST_LEG_DEPARTURE",
        "country": "UNITED STATES"
    },
    "GIP" : {
        "case": "LAST_LEG_DEPARTURE",
        "country": "UNITED STATES"
    },
    "TAW" : { 
        "case" : "FIRST_LEG_ARRIVAL",
        "country" : "UNITED STATES"
    },
    "UMR-W" : {
        "case" : "FIRST_LEG_ARRIVAL",
        "country" : "UNITED STATES"
    }
};

module.exports.LEG_COUNTRY_LIST = {
    IN: 'INDIA',
	US: 'UNITED STATES',
    PAN: 'PANAMA CANAL', 
    SC: 'SUEZ CANAL',
    PAK: 'PAKISTAN',
    SA: 'SOUTH AFRICA'
};