const { connectToDB } = require('../db-connections/dbConfig');
require('dotenv').config();
const calculatedVoyageROBSchema = require('../models/calculatedVoyageROB.model');
const Voyage = require('../models/voyageVsl.model');
const Vsched = require('../models/vsched.model');
const pastVoyageROB = require('../models/voyageROB.model');
const portCar = require("../models/portCar.model");
const gCargo = require("../models/gcargo.model");
const { GLOBAL_FLEET, FUNCION_VALUES } = require('./calculate-rob-constants.js');
const { QUALIFYING_LEG_LIST } = require('./qualifying-leg-constant.js');

module.exports = function (context, req) {
    // Allocate Cosmos DB Connecion
    connectToDB().then(async () => {
        const currentDate = new Date().toISOString();

        // Execute logic over ongoing vessels - Starts
        let ongoingVoyageRes = await fetchOngoingVoyages(currentDate);
        context.log('Calculate ROB - Ongoing vessels', ongoingVoyageRes?.length);
        if (ongoingVoyageRes) {
            for (let index = 0; index < ongoingVoyageRes.length; index++) {
                ongoingVoyageRes[index]['vschedJourney'] = [];
                ongoingVoyageRes[index]['voyageROBs'] = null;
                ongoingVoyageRes[index]['vschedJourney'] = await getVschedDetails(ongoingVoyageRes[index]?.vslCode, ongoingVoyageRes[index]?.voyNum, ongoingVoyageRes[index]);
                const previousROB = await getPastVoyageROB(ongoingVoyageRes[index]?.vslCode, ongoingVoyageRes[index]?.voyNum - 1);
                ongoingVoyageRes[index]['voyageROBs'] = await calculateROB(ongoingVoyageRes[index]['vschedJourney'], previousROB);

                let utilizationConfig = QUALIFYING_LEG_LIST[ongoingVoyageRes[index]?.lob.includes('TRAMP') ? 'TRAMP' : ongoingVoyageRes[index]?.lob];
                if (typeof utilizationConfig !== 'undefined' && utilizationConfig !== null && ongoingVoyageRes[index]['voyageROBs']) {
                    ongoingVoyageRes[index]['voyageROBs'] = await qualifyingLegROB(ongoingVoyageRes[index]['voyageROBs'], utilizationConfig);
                }

                await createOrUpdateCalculatedROB(ongoingVoyageRes[index]?.vslCode, ongoingVoyageRes[index]?.voyNum, ongoingVoyageRes[index]);
            }
        }
        // Execute logic over ongoing vessels - Ends

        // Execute logic over scheduled vessels - Starts
        let scheduledVoyageRes = await fetchScheduledVoyages(currentDate);
        context.log('Calculate ROB - Scheduled vessels', scheduledVoyageRes?.length);
        if (scheduledVoyageRes) {
            for (let index = 0; index < scheduledVoyageRes.length; index++) {
                scheduledVoyageRes[index]['vschedJourney'] = [];
                scheduledVoyageRes[index]['voyageROBs'] = null;
                scheduledVoyageRes[index]['vschedJourney'] = await getVschedDetails(scheduledVoyageRes[index]?.vslCode, scheduledVoyageRes[index]?.voyNum, scheduledVoyageRes[index]);
                const previousVoyageROB = await getCalculatedROB(scheduledVoyageRes[index]?.vslCode, scheduledVoyageRes[index]?.voyNum - 1);
                scheduledVoyageRes[index]['voyageROBs'] = await calculateROB(scheduledVoyageRes[index]['vschedJourney'], previousVoyageROB);

                let utilizationConfig = QUALIFYING_LEG_LIST[ongoingVoyageRes[index]?.lob.includes('TRAMP') ? 'TRAMP' : ongoingVoyageRes[index]?.lob];
                if (typeof utilizationConfig !== 'undefined' && utilizationConfig !== null && scheduledVoyageRes[index]['voyageROBs']) {
                    scheduledVoyageRes[index]['voyageROBs'] = await qualifyingLegROB(scheduledVoyageRes[index]['voyageROBs'], utilizationConfig);
                }

                await createOrUpdateCalculatedROB(scheduledVoyageRes[index]?.vslCode, scheduledVoyageRes[index]?.voyNum, scheduledVoyageRes[index]);
            }
        }
        // Execute logic over scheduled vessels - Ends

        context.res = {
            status: 200,
            headers: { 'content-type': 'application/json' },
            body: {
                ongoingVoyageRes,
                scheduledVoyageRes
            }
        }
        context.log('Calculate ROB - Successfully executed');
        context.done();
    }).catch(error => {
        context.log('Calculate ROB - Error while cosmos connection ', error);
        context.done();
    })

    // Fetch voyages which are Ongoing.
    async function fetchOngoingVoyages(currentDate) {
        try {
            return await Voyage.aggregate([
                { $match: { commenceGmt: { $lte: new Date(currentDate) }, completeGmt: { $gte: new Date(currentDate) }, oprType: 'TCOV' , isDeleted: false } },
                {
                    $lookup: {
                        from: 'gvsl',
                        localField: 'vslCode',
                        foreignField: 'vsl_code',
                        as: 'gvsl_data'
                    }
                },
                { $unwind: "$gvsl_data" },
                { $match: { 'gvsl_data.fleet': GLOBAL_FLEET.STJS, 'gvsl_data.isDeleted': false } },
                { $sort: { voyNum: 1 } }
            ])
        } catch (err) {
            return err;
        }
    }

    // Fetch voyages which are Scheduled.
    async function fetchScheduledVoyages(currentDate) {
        try {
            return await Voyage.aggregate([
                { $match: { commenceGmt: { $gte: new Date(currentDate) }, oprType: 'TCOV' , isDeleted: false } },
                {
                    $lookup: {
                        from: 'gvsl',
                        localField: 'vslCode',
                        foreignField: 'vsl_code',
                        as: 'gvsl_data'
                    }
                },
                { $unwind: "$gvsl_data" },
                { $match: { 'gvsl_data.fleet': GLOBAL_FLEET.STJS, 'gvsl_data.isDeleted': false } },
                { $sort: { voyNum: 1 } }
            ])
        } catch (err) {
            return err;
        }
    }

    const getVschedDetails = async (vslCode, voyNum, voyageObj) => {
        return Vsched.aggregate([
            { $match: { ves_code: vslCode, voy_no_int: voyNum, isDeleted: false, func: { $in: [FUNCION_VALUES.FUNCTION_M, FUNCION_VALUES.FUNCTION_L, FUNCION_VALUES.FUNCTION_D, FUNCION_VALUES.FUNCTION_I] } } },
            {
                $lookup: {
                    from: 'rnports',
                    localField: 'port',
                    foreignField: 'name',
                    as: 'rnport_data'
                }
            },
            {
                $project: {
                    ves_code: 1,
                    voy_no_int: 1,
                    seq_no_int: 1,
                    ord_no_int: 1,
                    port_no: 1,
                    port: 1,
                    miles: 1,
                    p_arr_date: 1,
                    p_depart_date: 1,
                    func: 1,
                    rnport_data: {
                        country: 1,
                        fleet: 1,
                        isDeleted: 1
                    }
                },
            },
            { $unwind: "$rnport_data" },
            { $match: { 'rnport_data.fleet': voyageObj?.fleet, 'rnport_data.isDeleted': false, 'rnport_data.country': { $nin: [null, ""] } } },
            {
                $addFields: {
                    vesCodeVoyNoSeqNoKey: { $concat: ["$ves_code", { $toString: "$voy_no_int" }, { $toString: "$seq_no_int" }] },
                    LOB: voyageObj?.lob,
                    dwt: voyageObj?.gvsl_data?.dwt
                }
            },
            { $sort: { ord_no_int: 1 } }
        ])
    };

    const getPastVoyageROB = async (vslCode, voyNum) => {
        const robDetails = await pastVoyageROB.find({ szVesselCode: vslCode, idVoyageNumber: voyNum, isDeleted: false });
        const ROB = robDetails && robDetails.length ? robDetails[0].fROB : 0
        return ROB;
    }

    const calculateROB = async (vesselJourney, previousROB) => {
        if (vesselJourney?.length) {
            const vesselJourneyAgainstVslCodeVoyNum = {};
            vesselJourney.map(vessel => {
                const vslCodeVoyNumKey = `${vessel.ves_code}${vessel.voy_no_int}`;
                if (!vesselJourneyAgainstVslCodeVoyNum[vslCodeVoyNumKey]) {
                    vesselJourneyAgainstVslCodeVoyNum[vslCodeVoyNumKey] = [vessel];
                } else if (vesselJourneyAgainstVslCodeVoyNum[vslCodeVoyNumKey]) {
                    vesselJourneyAgainstVslCodeVoyNum[vslCodeVoyNumKey].push(vessel);
                }
            })

            try {
                const vesselsWithoutOrdNo = vesselJourney.map(details => {
                    return {
                        vsl_code: details.ves_code,
                        voyage: details.voy_no_int,
                        seq_no: details.seq_no_int,
                        isDeleted: false
                    }
                })

                let portCarDetails = [];
                portCarDetails = await getPortCarDetails(vesselsWithoutOrdNo);

                const vesselDetails = portCarDetails.map(details => {
                    return {
                        voyNo: details.voyage,
                        vslCode: details.vsl_code,
                        cargoId: details.cargoId,
                        isDeleted: false
                    }
                });

                let confirmedCargos = {};
                confirmedCargos = await getConfirmedCargos(vesselDetails, portCarDetails);

                if (!confirmedCargos?.error) {
                    for (const vessel in vesselJourneyAgainstVslCodeVoyNum) {
                        for (let i = 0; i < vesselJourneyAgainstVslCodeVoyNum[vessel].length; i++) {
                            let previousRob = 0;
                            if (i === 0) {
                                previousRob = previousROB;
                            } else if (i > 0) {
                                previousRob = vesselJourneyAgainstVslCodeVoyNum[vessel][i - 1]['ROB'];
                            }

                            vesselJourneyAgainstVslCodeVoyNum[vessel][i]['previousRob'] = previousRob;

                            const commonKey = vesselJourneyAgainstVslCodeVoyNum[vessel][i].vesCodeVoyNoSeqNoKey;
                            if (confirmedCargos && confirmedCargos[commonKey]) {
                                const totalLoadDischargeActivity =
                                    await calculateTotalLoadAndDischarge(confirmedCargos[commonKey]);
                                const ROB = previousRob + totalLoadDischargeActivity.totalLoad - totalLoadDischargeActivity.totalDischarge;
                                vesselJourneyAgainstVslCodeVoyNum[vessel][i]['ROB'] = ROB;
                            } else {
                                vesselJourneyAgainstVslCodeVoyNum[vessel][i]['ROB'] = previousRob;
                            }

                            vesselJourneyAgainstVslCodeVoyNum[vessel][i]['utilization'] =
                                vesselJourneyAgainstVslCodeVoyNum[vessel][i]['ROB'] / vesselJourneyAgainstVslCodeVoyNum[vessel][i].dwt;
                        }
                    }
                }
                return vesselJourneyAgainstVslCodeVoyNum;
            } catch (error) {
                context.log('Calculate ROB - Error while calculating ROBs ', error);
                throw error;

            }
        }
    }

    const getPortCarDetails = async (allVessels) => {
        return portCar.find({ $or: allVessels })
            .select({
                voyage: 1,
                vsl_code: 1,
                seq_no: 1,
                qtyBL: 1,
                func: 1,
                liftQty: 1,
                isDeleted: 1,
                cargoId: 1
            })
            .lean()
            .exec()
    }

    const getConfirmedCargos = async (vesselDetails, portCarDetails) => {
        try {
            if (vesselDetails?.length) {
                const portCarInfo = {};
                portCarDetails.forEach(portCarData => {
                    const vslCodeVoyNoCargoIdKey = `${portCarData.vsl_code}${portCarData.voyage}${portCarData.cargoId}`;
                    if (portCarInfo && !portCarInfo[vslCodeVoyNoCargoIdKey]) {
                        portCarInfo[vslCodeVoyNoCargoIdKey] = {};
                        portCarInfo[vslCodeVoyNoCargoIdKey][portCarData.seq_no] = portCarData;
                    } else if (portCarInfo && portCarInfo[vslCodeVoyNoCargoIdKey]) {
                        portCarInfo[vslCodeVoyNoCargoIdKey][portCarData.seq_no] = portCarData
                    }
                })

                const gCargoDetails = await gCargo
                    .aggregate([
                        {
                            $match: {
                                $or: vesselDetails,
                                cargoAssigned: 1
                            }
                        },
                        {
                            $project: {
                                vslCode: 1,
                                voyNo: 1,
                                cargoId: 1,
                                cargoAssigned: 1
                            }
                        }
                    ])

                const filteredCargos = {};
                gCargoDetails.forEach(details => {
                    const vslCodeVoyNoCargoIdKey = `${details.vslCode}${details.voyNo}${details.cargoId}`;
                    if (portCarInfo && portCarInfo[vslCodeVoyNoCargoIdKey]) {
                        filteredCargos[vslCodeVoyNoCargoIdKey] = portCarInfo[vslCodeVoyNoCargoIdKey];
                    }
                });

                const confirmedCargos = {};
                portCarDetails.forEach(portCarData => {
                    const vslCodeVoyNoCargoIdKey = `${portCarData.vsl_code}${portCarData.voyage}${portCarData.cargoId}`;
                    if (filteredCargos[vslCodeVoyNoCargoIdKey]) {
                        const vslCodeVoyNoSeqNoKey = `${portCarData.vsl_code}${portCarData.voyage}${portCarData.seq_no}`;
                        if (!confirmedCargos[vslCodeVoyNoSeqNoKey]) {
                            confirmedCargos[vslCodeVoyNoSeqNoKey] = [portCarData];
                        } else if (confirmedCargos[vslCodeVoyNoSeqNoKey]) {
                            confirmedCargos[vslCodeVoyNoSeqNoKey].push(portCarData)
                        }

                    }
                })

                return confirmedCargos;
            }
        } catch (error) {
            context.log('Calculate ROB - Error occurred while filtering out confirmed cargos from gcargo -', error);
            return { error: true, errorMessage: error }
        }
    }

    const calculateTotalLoadAndDischarge = async (confirmedCargos) => {
        let totalLoad = 0;
        let totalDischarge = 0;
        confirmedCargos.forEach(cargo => {
            if (cargo && cargo.func === FUNCION_VALUES.FUNCTION_L) {
                if(cargo.liftQty && cargo.liftQty > 0) {
                    if(cargo.qtyBL && cargo.qtyBL > 0) {
                        totalLoad += cargo.qtyBL;
                    } else {
                        totalLoad += cargo.liftQty;
                    }
                }
            } else if (cargo.func === FUNCION_VALUES.FUNCTION_D) {
                if(cargo.liftQty && cargo.liftQty > 0) {
                    if(cargo && cargo.qtyBL && cargo.qtyBL > 0) {
                        totalDischarge += cargo.qtyBL;
                    } else {
                        totalDischarge += cargo.liftQty;
                    }
                }
            }
        })
        return {
            totalLoad,
            totalDischarge
        }
    }

    const getCalculatedROB = async (vslCode, voyNum) => {
        const robDetails = await calculatedVoyageROBSchema.find({ vslCode: vslCode, voyNum: voyNum });
        const ROB = robDetails && robDetails.length ? robDetails[0].lastPortROB : 0
        return ROB;
    }


    const qualifyingLegROB = async (ROB, utilizationConfig) => {
        switch (utilizationConfig.case) {
            case 'FIRST_LEG_ARRIVAL':
                for (const currentROB in ROB) {
                    for (let i = 0; i < ROB[currentROB].length; i++) {
                        if (typeof ROB[currentROB][i + 1] !== 'undefined' && utilizationConfig.country.includes(ROB[currentROB][i + 1]?.rnport_data?.country)) {
                            ROB[currentROB][i + 1]['finalUtilization'] = true;
                            break;
                        }
                    }
                }
                break;
            case 'LAST_LEG_DEPARTURE':
                for (const currentROB in ROB) {
                    let temp = null;
                    for (let i = 0; i < ROB[currentROB].length; i++) {
                        if (typeof ROB[currentROB][i] !== 'undefined' && ROB[currentROB][i]?.rnport_data?.country === utilizationConfig.country) {
                            temp = i;
                        }
                    }
                    if(temp >= 0 && temp != null) {
                        ROB[currentROB][temp]['finalUtilization'] = true;
                    }
                }
                break;
            case 'FIRST_LEG_ARRIVAL_PORT':
                for (const currentROB in ROB) {
                    for (let i = 0; i < ROB[currentROB].length; i++) {
                        if (typeof ROB[currentROB][i + 1] !== 'undefined' && utilizationConfig.portNo.includes(ROB[currentROB][i].port_no)) {
                            ROB[currentROB][i + 1]['finalUtilization'] = true;
                            break;
                        }
                    }
                }
                break;
            case 'DEPARTING_PORT':
                for (const currentROB in ROB) {
                    for (let i = 0; i < ROB[currentROB].length; i++) {
                        if (typeof ROB[currentROB][i] !== 'undefined' && utilizationConfig.portNo.includes(ROB[currentROB][i].port_no)) {
                            ROB[currentROB][i]['finalUtilization'] = true;
                            break;
                        } else {
                            const miles = Math.max(...ROB[currentROB].map(m => m.miles));
                            const index = ROB[currentROB].findIndex(x => x.miles === miles);
                            ROB[currentROB][index]['finalUtilization'] = true;
                        }
                    }
                }
                break;
            case 'FIRST_LEG_DEPARTURE':
                for (const currentROB in ROB) {
                    for (let i = 0; i < ROB[currentROB].length; i++) {
                        if (typeof ROB[currentROB][i] !== 'undefined' && ROB[currentROB][i]?.rnport_data?.country === utilizationConfig.country) {
                            ROB[currentROB][i]['finalUtilization'] = true;
                            break;
                        }
                    }
                }
                break;
            case 'LEG_WITH_MAX_DISTANCE':
                for (const currentROB in ROB) {
                    const miles = Math.max(...ROB[currentROB].map(i => i.miles));
                    const index = ROB[currentROB].findIndex(x => x.miles === miles);
                    ROB[currentROB][index]['finalUtilization'] = true;
                }
                break;
            case 'HIGH_UTILISATION':
                for (const currentROB in ROB) {
                    const utilization = Math.max(...ROB[currentROB].map(i => i.utilization));
                    const index = ROB[currentROB].findIndex(x => x.utilization === utilization);
                    ROB[currentROB][index]['finalUtilization'] = true;
                }
                break;
        }
        return ROB;
    }

    const createOrUpdateCalculatedROB = async (vslCode, voyNum, obj) => {
        const qualifiedLeg = obj?.vschedJourney.find((e) => { return (e?.finalUtilization === true) });
        const responseObj = {
            vslCode: vslCode,
            voyNum: voyNum,
            vslCodeNum: `${vslCode}${voyNum}`,
            vslName: obj?.vslName,
            lob: obj?.lob,
            lastPortROB: obj?.vschedJourney[obj?.vschedJourney?.length - 1]?.ROB || 0,
            lastPortUtilization: obj?.vschedJourney[obj?.vschedJourney?.length - 1]?.utilization || 0,
            lastPortObj: {
                seq_no_int: obj?.vschedJourney[obj?.vschedJourney?.length - 1]?.seq_no_int,
                ord_no_int: obj?.vschedJourney[obj?.vschedJourney?.length - 1]?.ord_no_int,
                port_no: obj?.vschedJourney[obj?.vschedJourney?.length - 1]?.port_no,
                port: obj?.vschedJourney[obj?.vschedJourney?.length - 1]?.port,
            },
            qualifiedLegROB: qualifiedLeg?.ROB || 0,
            qualifiedLegUtilization: qualifiedLeg?.utilization || 0,
            qualifiedLegObj: {
                seq_no_int: qualifiedLeg?.seq_no_int,
                ord_no_int: qualifiedLeg?.ord_no_int,
                port_no: qualifiedLeg?.port_no,
                port: qualifiedLeg?.port,
            }
        }
        try {
            return calculatedVoyageROBSchema.updateOne(
                { voyNum, vslCode },
                { $set: { ...responseObj } },
                { upsert: true }
            );
        } catch (error) {
            context.log("Calculate ROB - Error occured while storing data from createOrUpdateCalculatedROB ", error);
            throw error;
        }
    }
}
