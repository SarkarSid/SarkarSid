module.exports.GLOBAL_FLEET = {
    STJS: 'STJS'
}

module.exports.FUNCION_VALUES = {
	FUNCTION_M: 'M',
    FUNCTION_L: 'L', 
    FUNCTION_D: 'D',
    FUNCTION_I: 'I'
};

