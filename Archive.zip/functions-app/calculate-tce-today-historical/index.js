const { connectToDB } = require('../db-connections/dbConfig');
require('dotenv').config();
const calculateTCETodayService = require('../calculate-tce-today/tce-today.service');
const { successResponse } = require('../common/response');
const { DAYS_COUNT, GLOBAL_FLEET } = require('../common/common_constant');

module.exports = function (context, req) {
    /* call this FA without any params
       or pass start="YYYY-MM-DD" & end="YYYY-MM-DD" date (any valid format) as query parameter 
       and body with method POST */
    connectToDB().then(async () => {
        const days = req.query && req.query?.start && req.query?.end ? Math.abs((new Date(req.query?.end) - new Date(req.query?.start)) / GLOBAL_FLEET.TIME_TO_DAY_CALCULATION): DAYS_COUNT.ROLLING_TCE_DAYS;
        for(let i = days; i > 0; i--){
            const curdate = req.query && req.query?.end ? new Date(req.query?.end) : new Date();
            curdate.setDate(curdate.getDate() - i);
            const calculatedDate = new Date(curdate).toISOString().split('T')[0];
            const currentDate = new Date(`${calculatedDate}T00:00:00.000Z`);
            const endWindowDate = new Date(`${calculatedDate}T00:00:00.000Z`);
            endWindowDate.setDate(endWindowDate.getDate() + DAYS_COUNT.TCE_CAL_DAYS);
            await calculateTCETodayService.initiateTCECalculation(currentDate, endWindowDate, calculatedDate);
        }
        context.res = successResponse({msg: 'Execution completed successfully'})
        context.done();
    }).catch(error => {
        context.log('Historical TCE Today error: ', error);
        context.done();
    });
}
