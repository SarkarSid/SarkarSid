const voyage = require("../models/voyageVsl.model");
const commercialUtilization = require("../models/calculatedCommercialUtilization.model");
const { GLOBAL_FLEET, OPR_TYPE } = require('./utilization-constants.js');


const getUtilizationData = (startWindowDate) => {
    return voyage.aggregate([
    {$match:{ oprType: OPR_TYPE.TCOV, isDeleted:false,
    $or:[
        { $and: [{ commenceGmt: { $gte: new Date(startWindowDate) } }, { commenceGmt: { $lte: new Date() } }] },
        { $and: [{ completeGmt: { $gte: new Date(startWindowDate) } }, { completeGmt: { $lte: new Date() } }] },
        { $and: [{ commenceGmt: { $lte: new Date(startWindowDate) } }, { completeGmt: { $gte: new Date() } }] },
    ]}
    },
    {
    $lookup: {
        from: 'regions',
        localField: 'lob',
        foreignField: 'LOB',
        as: 'region_data'
    }
    },
    {$unwind:'$region_data'},
    {
    $lookup: {
        from: 'gvsl',
        localField: 'vslCode',
        foreignField: 'vsl_code',
        as: 'gvsl_data'
    }
    },
    {$unwind:'$gvsl_data'},
    {
    $lookup: {
        from: 'detailedVoyageROB',
        localField: 'vesVoy',
        foreignField: 'vesVoy',
        as: 'detailedROB_data'
    }
    },
    {
    $lookup: {
        from: 'vsched',
        localField: 'vesVoy',
        foreignField: 'vesVoy',
        as: 'vsched_data'
    }
    },
    {$unwind:'$vsched_data'},
    {$match:{'vsched_data.isDeleted':false}},
    {$sort:{'vsched_data.ord_no_int':1}},
    {
    $lookup: {
    from: "rnports",
    localField: "vsched_data.port_no",   
    foreignField: "no",
    as: "vsched_data.rnPort_data",
    },
    },
    {
    $addFields: {
    "vsched_data.rnPort_data": {
    $filter: {
    input: "$vsched_data.rnPort_data",
    as: "rnport",
    cond: {
        $and: [
        { $eq: ["$$rnport.fleet", GLOBAL_FLEET.STJS] },
        {
            $eq: [
            "$$rnport.isDeleted",
            false,
            ],
        },
        {
            $ne: ["$$rnport.country", [null, ""] ]
        }
        ],
    },
    },
    },
    },
    },
    {
    $unwind: {
    path: "$vsched_data.rnPort_data",
    preserveNullAndEmptyArrays: true,
    },
    },
    {$group: { _id: "$_id",startVschedDetails: { $first: "$$ROOT" }, vsched_data: { $push: "$vsched_data" } } },
    {$project:{
        vesselName:'$startVschedDetails.vslName',
        vslCode: '$startVschedDetails.vslCode',
        voyNum: '$startVschedDetails.voyNum',
        commenceDate: '$startVschedDetails.commenceGmt',
        completedDate: '$startVschedDetails.completeGmt',
        oprType: '$startVschedDetails.oprType',
        lob: '$startVschedDetails.lob',
        region:'$startVschedDetails.region_data.parent_region',       
        vsl_type:'$startVschedDetails.gvsl_data.vsl_type',
        capacity:{$toInt: '$startVschedDetails.gvsl_data.dwt'},
        yearBuilt:'$startVschedDetails.gvsl_data.yearBuilt',
        startPort:'$startVschedDetails.vsched_data.port',
        vschedJourney: '$vsched_data',
        detailedVoyRob: {
            $filter: {
                input: "$startVschedDetails.detailedROB_data",
                as: "rob",
                cond: {$and : {$eq: ["$$rob.isDeleted",false]}}
                
            }
        }
        }
    },
    ]);
}
const updateCommercialUtilizationDataRepo = (obj, currentDate) => {
    return commercialUtilization.findOneAndUpdate({
        windowEndDate: new Date(currentDate)
    }, obj, { upsert: true, new: true });
}
module.exports = {
    getUtilizationData,
    updateCommercialUtilizationDataRepo
}