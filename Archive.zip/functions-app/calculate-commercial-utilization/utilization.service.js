const {
    getUtilizationData,
    updateCommercialUtilizationDataRepo
} = require("./utilization.repository");
const _ = require("lodash");
const { QUALIFYING_LEG_LIST, ALL_LOBS, QUALIFYING_LEG_CASES } = require('./qualifyingLeg-constant');

const initiateUtilizationCalculation = async (start, end, exportCheck = '') => {
    const utilizationData = await getUtilizationData(start);
        const resultArr = [];
        for(const el of utilizationData) {
            const rob = await getVesselDetailsWithUtilization(el, el.lob);
            el.rob = rob.rob;
            resultArr.push(
                {
                    vesselName:el.vesselName,
                    vslCode:el.vslCode,
                    voyNum:el.voyNum,
                    lob:el.lob,
                    region:el.region,
                    capacity:el.capacity,
                    rob:el.rob,
                    qualifiedLegOrderNo:rob.qualifiedLegOrderNo,
                    isMaxROB:rob.isMaxROB,
                    startPort:el.startPort,
                    utilization:el.rob/el.capacity*100,
                    commenceDate:el.commenceDate,
                    completedDate:el.completedDate,
                })
        }
        const ans = _(resultArr)
        .groupBy('region')
        .map((region, id) => ({
        region: id,
        capacity: _.sumBy(region, 'capacity'),
        rob: _.sumBy(region, 'rob'),
        utilization : _.sumBy(region, 'rob')/_.sumBy(region, 'capacity')*100,
        lobs: getLobList(region)
        }))
        .value()

        const mainObj = {
            windowStartDate : start,
            windowEndDate: end,
            totalCapacity:_.sumBy(resultArr,'capacity'),
            totalRob:_.sumBy(resultArr,'rob'),
            totalUtilization:_.sumBy(resultArr,'rob')/_.sumBy(resultArr,'capacity')*100,
            regions:ans
        }
        const curdate = new Date().toISOString().split('T')[0];
        if(exportCheck !== 'exportData'){
            await updateCommercialUtilizationDataRepo(mainObj,curdate);
        }
        return resultArr;
}
const getLobList = (region) =>{
   const lob =  _(region, (item) => item.lob).groupBy('lob')
            .map((lobGroup, lob) => ({
                lob: lob,
                capacity: _.sumBy(lobGroup, 'capacity'),
                rob: _.sumBy(lobGroup, 'rob'),
                utilization:_.sumBy(lobGroup, 'rob')/_.sumBy(lobGroup, 'capacity')*100
            })).value()
    return lob;
}
const getVesselDetailsWithUtilization = async (vesselData, LOB) => {
    const robAndUtilization =  await getRobAndUtilization(vesselData, LOB); 
    return { rob: robAndUtilization.ROB ? robAndUtilization.ROB : null,
        isMaxROB : robAndUtilization.isMaxROB ,
        qualifiedLegOrderNo: robAndUtilization.qualifiedLegOrderNo}
}
const getRobAndUtilization = async (vessel, LOB) => {
    let qualifiedLeg;
    let qualifiedLegROB = {}; 
    let isMaxROB = null;
    if(ALL_LOBS.LOBS_FOR_QUALIFYING_LEG.includes(LOB)) {
        qualifiedLeg = await qualifyingLeg(QUALIFYING_LEG_LIST[LOB], vessel.vschedJourney);
        if(qualifiedLeg) {
            qualifiedLegROB = vessel.detailedVoyRob.find(voyage =>
                voyage.szVesselCode === qualifiedLeg.ves_code && voyage.idVoyageNumber === qualifiedLeg.voy_no_int && voyage.ord_no === qualifiedLeg.ord_no_int
            );
        }
    } else {
        isMaxROB = true;
        const ordNos = vessel.vschedJourney.map(vessel => vessel.ord_no_int)
        const detailedVoyRob = vessel.detailedVoyRob.filter(vessel => ordNos.includes(vessel.ord_no));
        const maxROB = Math.max(...detailedVoyRob.map(i => i.ROB));
        qualifiedLegROB['ROB'] = maxROB;
    } 
    return {
        ROB : qualifiedLegROB && qualifiedLegROB.ROB ? qualifiedLegROB.ROB : 0,
        isMaxROB,
        qualifiedLegOrderNo : qualifiedLeg && qualifiedLeg?.ord_no_int ? qualifiedLeg.ord_no_int : null
    }
}
const qualifyingLeg = async(utilizationConfig, vschedJourney) => {
    let qualifiedLeg;
    switch (utilizationConfig.case) {
        case QUALIFYING_LEG_CASES.LEG_WITH_MAX_DISTANCE:
            const displayedDistToPort = Math.max(...vschedJourney.map(i => i.displayedDistToPort));
            const index = vschedJourney.findIndex(x => x.displayedDistToPort === displayedDistToPort);
            if((utilizationConfig && utilizationConfig.distance && displayedDistToPort > utilizationConfig.distance) || !utilizationConfig.distance) {
                qualifiedLeg = (index === 0) ? vschedJourney[index] : vschedJourney[index - 1];
            }
            break;
        case QUALIFYING_LEG_CASES.LAST_LEG_DEPARTURE:
                for(const vessel of vschedJourney) {
                    if(vessel.rnPort_data.country === utilizationConfig.country) {
                        qualifiedLeg = vessel;
                    }
                }
            break;
        case QUALIFYING_LEG_CASES.DEPARTING_PORT:
            for(const vessel of vschedJourney) {
                if(utilizationConfig.portNo.includes(vessel.port_no)) {
                    qualifiedLeg = vessel;
                    break;
                }
            }
            break;
        case QUALIFYING_LEG_CASES.FIRST_LEG_ARRIVAL:
                const legIndex = vschedJourney.findIndex(vessel => utilizationConfig.country.includes(vessel.rnPort_data.country))
                if(legIndex > 0) {
                    qualifiedLeg = vschedJourney[legIndex - 1];
                }
        break;
        case QUALIFYING_LEG_CASES.FIRST_LEG_ARRIVAL_PORT:
                const arrPortIndex = vschedJourney.findIndex(vessel => utilizationConfig.portNo.includes(vessel.port_no))
                if(arrPortIndex > 0) {
                    qualifiedLeg = vschedJourney[arrPortIndex - 1];
                }
        break;
        case QUALIFYING_LEG_CASES.DEPARTING_PORT_OR_LEG_WITH_MAX_DISTANCE:
            const suezPortIndex = vschedJourney.findIndex(vessel => utilizationConfig.portNo.includes(vessel.port_no))
            if(suezPortIndex > 0) {
                qualifiedLeg = vschedJourney[suezPortIndex];
            } else {
                const displayedDistToPort = Math.max(...vschedJourney.map(i => i.displayedDistToPort));
                const index = vschedJourney.findIndex(x => x.displayedDistToPort === displayedDistToPort);
                if(utilizationConfig && utilizationConfig.distance && displayedDistToPort > utilizationConfig.distance) {
                    qualifiedLeg = (index === 0) ? vschedJourney[index] : vschedJourney[index - 1];
                }
            }
        break;

    }
    return qualifiedLeg;

}
module.exports = {
    initiateUtilizationCalculation
}