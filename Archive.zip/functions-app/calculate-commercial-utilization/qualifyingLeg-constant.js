module.exports.QUALIFYING_LEG_LIST = {
    "AGE": {
        "case": "LEG_WITH_MAX_DISTANCE",
    },
    "TPW" : { 
        "case": "DEPARTING_PORT",
        "portNo": [24040]
    },
    "GIR-U": {
        "case": "DEPARTING_PORT",
        "portNo": [20128]
    },
    "BAJ": {
        "case": "LEG_WITH_MAX_DISTANCE",
        "distance": 2000
    },
    "HBR-C": {
        "case": "LEG_WITH_MAX_DISTANCE",
        "distance": 1000
    },
    "JAB": {
        "case": "LEG_WITH_MAX_DISTANCE",
        "distance": 3000
    },
    "LAS-EN": {
        "case": "LEG_WITH_MAX_DISTANCE",
        "distance": 2000
    },
    "GIP" : {
        "case": "LAST_LEG_DEPARTURE",
        "country": "UNITED STATES"
    },
    "LAS-ES" : {
        "case": "LAST_LEG_DEPARTURE",
        "country": "UNITED STATES"
    },
    "TAE" : {
        "case": "LAST_LEG_DEPARTURE",
        "country": "UNITED STATES"
    },
    "UMR-E" : {
        "case": "LAST_LEG_DEPARTURE",
        "country": "UNITED STATES"
    },
    "TAW" : { 
        "case" : "FIRST_LEG_ARRIVAL",
        "country" : "UNITED STATES"
    },
    "UMR-W" : {
        "case" : "FIRST_LEG_ARRIVAL",
        "country" : "UNITED STATES"
    },
    "EXP-A": {
        "case": "FIRST_LEG_ARRIVAL",
        "country": ["INDIA", "PAKISTAN"]
    },
    "GIR-C" : {
        "case": "FIRST_LEG_ARRIVAL_PORT",
        "portNo": [20128]
    },
    "PACS" : {
        "case": "FIRST_LEG_ARRIVAL_PORT",
        "portNo": [20128]
    },
    "HBR-U": {
        "case": "DEPARTING_PORT_OR_LEG_WITH_MAX_DISTANCE",
        "portNo": [20128],
        "distance": 1000
    },
    "AAG": {
        "case": "LEG_WITH_MAXIMUM_ROB"
    },
    "ESA-N": {
        "case": "LEG_WITH_MAXIMUM_ROB"
    },
    "EXP-P": {
        "case": "LEG_WITH_MAXIMUM_ROB"
    },
    "GIR-M": {
        "case": "LEG_WITH_MAXIMUM_ROB"
    },
    "KISAN": {
        "case": "LEG_WITH_MAXIMUM_ROB"
    },
    "LAS-W": {
        "case": "LEG_WITH_MAXIMUM_ROB"
    },
    "POS-TRAMP": {
        "case": "LEG_WITH_MAXIMUM_ROB"
    },
    "TAS-TRAMP": {
        "case": "LEG_WITH_MAXIMUM_ROB"
    },
    "IOS-TRAMP": {
        "case": "LEG_WITH_MAXIMUM_ROB"
    },
    "AOS-TRAMP": {
        "case": "LEG_WITH_MAXIMUM_ROB"
    },


};

module.exports.LEG_COUNTRY_LIST = {
    IN: 'INDIA',
	US: 'UNITED STATES',
    PAN: 'PANAMA CANAL', 
    SC: 'SUEZ CANAL',
    PAK: 'PAKISTAN',
    SA: 'SOUTH AFRICA'
};

module.exports.ALL_LOBS = {
   LOBS_FOR_QUALIFYING_LEG : ['AGE','LAS-ES','TPW','GIR-U', 'BAJ','HBR-C', 'JAB', 'LAS-EN','GIP','LAS-ES','TAE', 'UMR-E', 'EXP-A','TAW','UMR-W', 'GIR-C', 'PACS','HBR-U' ],
   EXCLUDED_LOBS : ['DDD', 'WCAC-EU']
}

module.exports.QUALIFYING_LEG_CASES = {
    LEG_WITH_MAX_DISTANCE: 'LEG_WITH_MAX_DISTANCE',
    LAST_LEG_DEPARTURE: 'LAST_LEG_DEPARTURE',
    DEPARTING_PORT: 'DEPARTING_PORT',
    FIRST_LEG_ARRIVAL: 'FIRST_LEG_ARRIVAL',
    FIRST_LEG_ARRIVAL_PORT: 'FIRST_LEG_ARRIVAL_PORT',
    DEPARTING_PORT_OR_LEG_WITH_MAX_DISTANCE: 'DEPARTING_PORT_OR_LEG_WITH_MAX_DISTANCE'
}