const { DAYS_COUNT } = require('../common/common_constant');
const { successResponseWithData } = require('../common/response');
const { connectToDB } = require('../db-connections/dbConfig');
require('dotenv').config();

const { initiateUtilizationCalculation } = require('./utilization.service');

module.exports = function (context, req) {
    connectToDB().then(async () => {
        const today = new Date().toISOString().split('T')[0];
        const endDate = new Date(`${today}T00:00:00.000Z`);
        const startDate = new Date(`${today}T00:00:00.000Z`);
        startDate.setDate(endDate.getDate() - DAYS_COUNT.UTILIZATION_DAYS);
        const response = await initiateUtilizationCalculation(startDate, endDate, exportCheck = '');

        context.res = successResponseWithData(response);
        context.log('Utilization calculation executed successfully');
        context.done();
    }).catch(error => {
        context.log('Utilization error: ', error);
        throw error;
    })
    
    

    
}
