module.exports.GLOBAL_FLEET = {
    STJS: 'STJS'
}
module.exports.OPR_TYPE = {
    TCOV: 'TCOV',
    TCTO: 'TCTO'
}
