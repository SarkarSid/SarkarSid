
const { GLOBAL_FLEET, CREATE_VOYAGE_REQUEST_STATUS } = require('../common/common_constant');
const  createVoyageLogs = require('../models/createVoyageLogs.model');
const  voyageDraft = require('../models/voyageDraft.model');

const updateCreateVoyageLogsInfo = async (vesVoy, isValid) => {
    return createVoyageLogs.updateMany(
        { nextVesVoy: vesVoy.toString(), $or: [{ isValid: true }, { isValid: { $exists: false } }] },
        {
            $set: { isValid: isValid }
        }
    );
}

const getCreateVoyageLogsInfo = async()=>{
    return createVoyageLogs.aggregate([
    {
        $match:{
            Status: { $ne: CREATE_VOYAGE_REQUEST_STATUS.ERROR },
            $or:[{isValid:true},{isValid: { $exists: false}}],
        }
    },
    {
        $lookup: {
            from: "voyage",
            localField: "vesVoy",
            foreignField: "vesVoy",
            as: "previousVoyageInfo",
        },
    },
    {$unwind: { path: '$previousVoyageInfo', preserveNullAndEmptyArrays: false } },
    {
        $lookup: {
            from: "voyage",
            localField: "nextVesVoy",
            foreignField: "vesVoy",
            as: "voyageInfo",
        },
    },
    {$unwind: { path: '$voyageInfo', preserveNullAndEmptyArrays: false } },
    {
        $lookup: {
            from: "vsched",
            localField: "nextVesVoy",
            foreignField: "vesVoy",
            as: "vschedInfo",
        },
    }
    ]);
}
const getVoyageDraftInfo = async()=>{
    return voyageDraft.aggregate([
    {
        $match: {
            $and: [
                { $or: [{ isValid: true }, { isValid: { $exists: false } }] },
                { isDeleted: false }
              ]
        }
    },
    {
        $lookup: {
            from: "itinvest",
            localField: "estimateID",
            foreignField: "vsl_voy_id",
            as: "itinvest",
        },
    },
    {
        $lookup: {
            from: "brkvest",
            localField: "estimateID",
            foreignField: "vsl_voy_id",
            as: "brkvest",
        },
    },
    {
        $lookup: {
            from: "vest",
            localField: "estimateID",
            foreignField: "vsl_voy_id",
            as: "vest",
        },
    },
    {
        $lookup: {
            from: "expvest",
            localField: "estimateID",
            foreignField: "vsl_voy_id",
            as: "expvest",
        },
    },
    {
        $lookup: {
            from: "vcarvest",
            localField: "estimateID",
            foreignField: "vsl_voy_id",
            as: "vcarvest",
        },
    },
    {
        $addFields: {
          itinvestCount: {
            $filter: {
              input: "$itinvest",
              as: "itinvest_data",
              cond: { $and: [{ $eq: ["$$itinvest_data.isDeleted", false] }] },
            },
          },
          brkvestCount: {
            $filter: {
              input: "$brkvest",
              as: "brkvest_data",
              cond: { $and: [{ $eq: ["$$brkvest_data.isDeleted", false] }] },
            },
          },
          vestCount: {
            $filter: {
              input: "$vest",
              as: "vest_data",
              cond: { $and: [{ $eq: ["$$vest_data.isDeleted", false] }] },
            },
          },
          expvestCount: {
            $filter: {
              input: "$expvest",
              as: "expvest_data",
              cond: { $and: [{ $eq: ["$$expvest_data.isDeleted", false] }] },
            },
          },
          vcarvestCount: {
            $filter: {
              input: "$vcarvest",
              as: "vcarvest_data",
              cond: { $and: [{ $eq: ["$$vcarvest_data.isDeleted", false] }] },
            },
          },
        }
    },
    {
        $lookup: {
            from: "voyage",
            localField: "vesVoy",
            foreignField: "vesVoy",
            as: "previousVoyageInfo",
        },
    },
    {$unwind: { path: '$previousVoyageInfo', preserveNullAndEmptyArrays: false } },
    {
        $lookup: {
            from: "vsched",
            localField: "vesVoy",
            foreignField: "vesVoy",
            as: "previousVschedInfo",
        },
    },
    { $unwind: '$previousVschedInfo' },
    { $match: { 'previousVschedInfo.isDeleted': false } },
    { $sort: { 'previousVschedInfo.ord_no_int': 1 } },
    { $group: { _id: "$_id", endVschedDetails: { $last: "$$ROOT" } } },
    {
    $lookup: {
        from: 'rnports',
        localField: 'endVschedDetails.previousVschedInfo.port_no',
        foreignField: 'no',
        as: 'rnPort_data'
    }
    },
    {$unwind:'$rnPort_data'},
    {$match:{'rnPort_data.isDeleted':false, 'rnPort_data.fleet':GLOBAL_FLEET.STJS}},
    {
    $lookup: {
        from: 'servicebasedlocationrefes',
        localField: 'rnPort_data.defaultLocationRef',
        foreignField: 'defaultLocationRefs',
        as: 'defaultLocationRef'
    }
    },
    {
    $lookup: {
        from: 'servicebasedlocationrefes',
        localField: 'rnPort_data.locationRef',
        foreignField: 'locationRefs',
        as: 'locationRef'
    }
    },
    {$addFields: {region: {$ifNull: ["$defaultLocationRef.serviceArea","$locationRef.serviceArea"]}}},
    {$unwind: {path: "$region",preserveNullAndEmptyArrays: true}},
    {
        $lookup: {
            from: "voyage",
            localField: "endVschedDetails.nextVesVoy",
            foreignField: "vesVoy",
            as: "voyageInfo",
        },
    },
    {$unwind: { path: '$voyageInfo', preserveNullAndEmptyArrays: true } },
    {
        $lookup: {
            from: "vsched",
            localField: "endVschedDetails.nextVesVoy",
            foreignField: "vesVoy",
            as: "vschedInfo",
        },
    }
    ]);
    
}
const updateVoyageDraftInfo = async (vslCode, voyNum, updatedData) => {
    const newUpdatedData = JSON.parse(JSON.stringify(updatedData));
    return voyageDraft.findOneAndUpdate(
        { vslCode: vslCode.toString(), voyNum: parseInt(voyNum), isDeleted: false, $or: [{ isValid: true }, { isValid: { $exists: false } }] },
        {
            $set: newUpdatedData
        }
    );
}

module.exports = {
    updateCreateVoyageLogsInfo,
    getCreateVoyageLogsInfo,
    getVoyageDraftInfo,
    updateVoyageDraftInfo
}