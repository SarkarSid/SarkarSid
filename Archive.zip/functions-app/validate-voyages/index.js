const { connectToDB } = require('./dbConfig');
const { updateCreateVoyageLogsInfo, getCreateVoyageLogsInfo, getVoyageDraftInfo, updateVoyageDraftInfo } = require("./validate-voyages-repository");
require('dotenv').config();

module.exports = function (context, req) {
    //NOSONAR Cosmos DB Demo Deployment
    connectToDB().then(async () => {
        const data = await getValidCreateVoyageLogsInfo();
        const voyageData = await getValidDraftVoyageInfo();
        const result = await verifyVoyages(data,false);
        const draftResult = await verifyVoyages(voyageData,true);
        if (result) {
            context.res = {
                status: 200,
                headers: { 'content-type': 'application/json' },
                body: { 'status': 200, 'message': 'Success', 'success': true, result, draftResult }
            }
            context.done();
        } else {
            context.res = {
                status: 400,
                headers: { 'content-type': 'application/json' },
                body: { 'status': 400, 'message': 'Record Not Found', 'success': false }
            }
            context.done();
        }
    }).catch(error => {
        console.error('Error while connection: ', error);
        context.res = {
            status: 400,
            headers: { 'content-type': 'application/json' },
            body: { 'status': 400, 'message': 'Connection Error - ' + error, 'success': false }
        }
        context.done();
    })
    async function getValidCreateVoyageLogsInfo() {
        try {
           return await getCreateVoyageLogsInfo();
        } catch (err) {
            context.log('Error while getting data', err);
            return err
        }
    }
    async function getValidDraftVoyageInfo() {
        try {
           return await getVoyageDraftInfo();
        } catch (err) {
            context.log('Error while getting data', err);
            return err
        }
    }
    async function verifyVoyages(data,isDraft){
        try{
            if(data && data.length){
                let isValid = true;
                let startDate = undefined;
                for(const result of data){
                    if(!isDraft){
                        if(result?.previousVoyageInfo && result.previousVoyageInfo.isDeleted === true)
                            isValid = false;
                        else if(result?.previousVoyageInfo && result.previousVoyageInfo.isDeleted === false && result?.voyageInfo && result.voyageInfo.isDeleted === false && result.vschedInfo.length > 0)
                            isValid = false;
                        else 
                            isValid = true;
                    } else {
                        startDate = undefined;
                        if(result?.endVschedDetails.previousVoyageInfo && result.endVschedDetails.previousVoyageInfo.isDeleted === true)
                            isValid = false;
                        else if(result?.endVschedDetails.previousVoyageInfo && result.endVschedDetails.previousVoyageInfo.isDeleted === false && result?.voyageInfo && result.voyageInfo.isDeleted === false && result.vschedInfo.length > 0)
                            isValid = false;
                        else if(result?.endVschedDetails.previousVoyageInfo && (result?.endVschedDetails.region !== result.region) )
                            isValid = false;
                        else if(result?.endVschedDetails.itinvestCount.length === 0 && result?.endVschedDetails.brkvestCount.length === 0 && result?.endVschedDetails.vestCount.length === 0 && result?.endVschedDetails.expvestCount.length === 0 && result?.endVschedDetails.vcarvestCount.length === 0)
                            isValid = false;
                        else if(result?.endVschedDetails.previousVoyageInfo && (new Date(result?.endVschedDetails.startDate).getTime() !== new Date(result?.endVschedDetails.previousVoyageInfo.completeGmt).getTime()) )
                            startDate = result?.endVschedDetails.previousVoyageInfo.completeGmt; 
                        else 
                            isValid = true;
                    }
                    !(isDraft) ? 
                        await updateCreateVoyageLogsInfo(result?.nextVesVoy,isValid): 
                        await updateVoyageDraftInfo(result?.endVschedDetails.vslCode,result?.endVschedDetails.voyNum,{isValid, startDate});
                }
            }
            return true;
        } catch(err){
            context.log('Error while performing Calculation', err);
            return err
        }
    }

}
