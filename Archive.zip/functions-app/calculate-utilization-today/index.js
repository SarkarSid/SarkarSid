const { connectToDB } = require('../db-connections/dbConfig');
require('dotenv').config();
const calculatedVoyageROB = require('../models/calculatedVoyageROB.model');
const utilizationToday = require('../models/utilizationToday.model');
const vsched = require('../models/vsched.model');
const regions = require('../models/regions.model');
const {GLOBAL_FLEET,OPR_TYPE} = require('../common/common_constant');
const servicebasedlocationrefes = require("../models/serviceBasedLocationRef.model");
const rnPorts = require("../models/rnportsData.model");
const _ = require("lodash");
const { errorResponse, successResponse } = require('../common/response');
module.exports = function (context, req) {
    connectToDB().then(async () => {
        const currentDate = new Date().toISOString();
        const res = await getVesselsListForUtilization(currentDate);
        await calculateUtilizationToday(res); 
        if (res) {
            context.res = successResponse({message: 'Success'});
            context.done();
        } else {
            context.res = errorResponse({message: 'Record Not Found'});
            context.done();
        }
    }).catch(error => {
        console.error('Error while connection: ', error);
        context.res = errorResponse({message: 'Connection Error - ' + error});
        throw error;
    })
    async function getVesselsListForUtilization(currentDate) {
        try {
        return regions.aggregate([
            {
                $lookup: {
                  from: 'voyage',
                  localField: 'LOB',
                  foreignField: 'lob',
                  as: 'voyage_data'
                }
              },
              {$unwind:'$voyage_data'},
              {$match:{'voyage_data.isDeleted':false,'voyage_data.oprType':OPR_TYPE.TCOV,
              'voyage_data.commenceGmt': { $lte: new Date(currentDate) },
                  'voyage_data.completeGmt': { $gte: new Date(currentDate) }}},
              {
                $lookup: {
                  from: 'gvsl',
                  localField: 'voyage_data.vslCode',
                  foreignField: 'vsl_code',
                  as: 'gvsl_data'
                }
              },
              {$unwind:'$gvsl_data'},
              {$match:{'gvsl_data.isDeleted':false, 'gvsl_data.fleet': GLOBAL_FLEET.STJS}},
              {$project:{
                  vslCode:'$voyage_data.vslCode',
                  voyNum:'$voyage_data.voyNum',
                  vslName:'$voyage_data.vslName',
                  startingDateTime:'$voyage_data.startingDateTime',
                  endingDateTime:'$voyage_data.endingDateTime',
                  LOB:1,
                  completeGmt:'$voyage_data.completeGmt',
                  commenceGmt:'$voyage_data.commenceGmt',
                  dwt:'$gvsl_data.dwt',
                  region:'$parent_region'
                }
            },
        ])
        } catch (err) {
            throw err;
        }
    }
    async function calculateUtilizationToday(voyageList){
        const voyageListArr = [];
        for(const vesVoy of voyageList){
            const {vslCode,voyNum,LOB,region} = vesVoy;
            const [rob] = await getCalculateRob(vslCode,voyNum);
            vesVoy['rob'] = rob.qualifiedLegROB;
            vesVoy['serviceArea'] = region;
            if(LOB.includes('TRAMP')){
                const [portsData] = await getPortsData(vslCode,voyNum);
                vesVoy['startPort'] = portsData.port;
                const serviceArea = await getServiceAreaBasedOnPort(vesVoy['startPort']);
                vesVoy['serviceArea'] = serviceArea;
            }
            voyageListArr.push({...vesVoy});
        }
        const totalRob = _.sumBy(voyageListArr, 'rob');
        const totalDwt = _.sumBy(voyageListArr, 'dwt');
        const totalUtilization = (totalRob/totalDwt)*100;
        const ans = _(voyageListArr)
        .groupBy('serviceArea')
        .map((serviceArea, id) => ({
            serviceArea: id,
            totalRob: _.sumBy(serviceArea, 'rob'),
            totalDwt: _.sumBy(serviceArea, 'dwt'),
            utilization: (_.sumBy(serviceArea, 'rob')/_.sumBy(serviceArea, 'dwt')) * 100
        }))
        .value()
        const mainObj = {
            totalRob,
            totalDwt,
            totalUtilization,
            regionWiseUtilization : ans
        }
        await updateCreateUtilizationToday(mainObj);
    }
    async function getServiceAreaBasedOnPort(port){
        let serviceArea = null;
        const [data] = await getRnPortsData(port.toUpperCase())
        /* find service area regarding defaultlocationrefs */
        if (data?.defaultLocationRef != null && data?.defaultLocationRef != '') {
            const [serviceAreaObj] = await getServiceAreaByDefaultLocationRefs(data?.defaultLocationRef);
            serviceArea = serviceAreaObj?.serviceArea ? serviceAreaObj?.serviceArea : null;
        } else {
            const [serviceAreaObjLocationRef] = await getServiceAreaByLocationRefs(data?.locationRef);
            serviceArea = serviceAreaObjLocationRef?.serviceArea ? serviceAreaObjLocationRef?.serviceArea : null;
        }
        return serviceArea;
    }
    async function getRnPortsData(port){
        try{
            return rnPorts.find({ name: port, isDeleted: false , fleet: GLOBAL_FLEET.STJS}).sort({ _id: -1 }).lean().exec();
        } catch(err){
            throw err;
        }
    }
    async function getServiceAreaByDefaultLocationRefs(defaultLocationRef){
        try{
            return servicebasedlocationrefes.find({ defaultLocationRefs: defaultLocationRef });
        } catch(err){
            throw err;
        }
    }
    async function getServiceAreaByLocationRefs(locationRef){
        try{
            return servicebasedlocationrefes.find({ locationRefs: locationRef });
        } catch(err){
            throw err;
        }
    }
    async function updateCreateUtilizationToday(obj) {
        try {
            const curdate = new Date().toISOString();
            const currentDate = curdate.split('T')[0];
            return utilizationToday.findOneAndUpdate({ createdAt: {$gte:new Date(currentDate) }}, obj,{upsert: true, new: true});
        } catch (err) {
            throw err;
        }
    }
    async function getCalculateRob(vslCode,voyNum){
        try{
            return calculatedVoyageROB.find({vslCode,voyNum});
        } catch(err){
            throw err;
        }
    }
    async function getPortsData(vslCode,voyNum){
        try{
            return vsched.find({ves_code:vslCode,voy_no_int:voyNum,isDeleted:false}).sort({ord_no_int:1}).limit(1);
        } catch(err){
            throw err;
        }
    }
}
