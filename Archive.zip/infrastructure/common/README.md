# Introduction 
This is the central repository for Azure Infrastructure artifacts, that should be referenced by all Azure projects.

# Repository content
Artifacts in this repository are grouped into following folders

| Folder | Description |
| --- | --- |
| bicep-modules | Modules for setting up common infrastructure components |
| lookups | Reference lists in json format for commonly reused values |
| scripts | Powershell scripts for executing common IaC tasks that are not achievable with Bicep |


# How to use?
There are several options to reference the common repository in your project, depending on the DevOps organization your project belongs to. 

## Projects in DevOps organizations different than Stolt-BT
For projects that are hosted withing orgazniations different than Stolt-BT the easiest way to reference the common repository is by using [multiple repositories](https://learn.microsoft.com/en-us/azure/devops/pipelines/repos/multi-repo-checkout) checkout in your yaml pipelines:
1. Create a PAT token in the Stolt-BT devops organiztion with the READ Code privilage. Select to allow the token to be used by all organizations
2. In your DevOps project create a Service Connection to Azure Repos that would use the PAT token created in step 1
3. In the yaml pipeline add additiona repository resource definition:
```
resources:
  repositories:
  - repository: CommonInfrastructure
    type: git
    endpoint: <Service-Connection-Name>
    name: Shared-infrastructure/Common.Infrastructure
    ref: refs/heads/main 
```
Things to note:
- replace 'endpoint' parameter with the name of the Service Connection created in step 2
- For 'ref' parameter you can use pointer to the latest git Tag to avoid breaking changes in future e.g. refs/tags/v0.1

4. Use multiple checkout steps:
```
      - job: Build
        steps:
          - checkout: self
            submodules: false

          - checkout: CommonInfrastructure
```
 
## Projects in the Stolt-BT DevOps organization
The easiest way to reference the common repository is by using [Git submodules](https://git-scm.com/book/en/v2/Git-Tools-Submodules):
1. Add Common.Infrastructure repository as a submodule of your main repo:
```
    git submodule add https://stolt-bt@dev.azure.com/stolt-bt/Shared-infrastructure/_git/Common.Infrastructure infrastructure/common
```
2. Checkin your .gitmodules file
3. Make sure that your yaml pipeline check outs submodules:
```
    - job: Build
      steps:
        - checkout: self
          submodules: true
```

# Contributing to common repository
If you would like to contribute to the common repository please follow the steps:
1. Develop your change in a dedicated GIT feature branch. Ensure that your change is generic enough to be reused by other projects
2. Create a pull request and assign responsible reviewers if not assigned automatically
3. Once the Pull Request is completed tag the common repository with appropriate version tag. Use [semenatic versioning](https://semver.org)
4. Reference the common repository in your code by using appropriate version tag

# General IaC guidelines

## Naming conventions

## KeyVault secrets

## Shared resources

