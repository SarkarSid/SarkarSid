# Script to register Azure AD apps for an API and its default client
# The script will create the following:
# - AAD app registration with a default role representing the API 
# - AAD app registration(s) representing the API client(s)
# - App permission for the API client(s) to access the API app
# - Client secret for the API client(s) AAD app that is stored in Key Vault
# More information:
# - https://docs.microsoft.com/en-us/azure/api-management/api-management-howto-protect-backend-with-aad
# - https://techcommunity.microsoft.com/t5/fasttrack-for-azure/protecting-apis-in-azure-api-management-using-oauth-2-0-client/ba-p/3054130

[CmdletBinding()]
param (
    [Parameter(Mandatory, HelpMessage="Name of the API app")]
    [string] $apiAppName,
    [Parameter(Mandatory, HelpMessage="Name of the KeyVault to be used for storing app registration secrets")]
    [string] $keyVaultName,    
    [Parameter(Mandatory=$False, HelpMessage="Optional array of App roles to define for the API app e.g. @('Document.Read','Document.Write'). The default Api.Access role is always added.")]
    [string[]] $apiRoles = @(), 
    [Parameter(Mandatory=$False, HelpMessage="Optional array of API client identifiers with required permissions array. E.g. @{ client1 = @('Document.Read', 'Document.Write')}")]
    [System.Object] $clientApps = @{},
    [Parameter(Mandatory, HelpMessage="Comma-separated list of aliases to assign as AAD app owners")]
    [string] $clientAppsOwners,
    [Parameter(Mandatory=$False, HelpMessage="Who can use registered applications? By defualt: Accounts in this organizational directory only. Allowed values: AzureADMultipleOrgs, AzureADMyOrg, AzureADandPersonalMicrosoftAccount, PersonalMicrosoftAccount")]
    [string] $signInAudience = 'AzureADMyOrg',
    [Parameter(Mandatory=$False, HelpMessage="Should app registration secrets be rotated automatically? Set to True only if secrets are not shared outside Stolt Azure subscription.")]
    [bool] $autoRotateSecrets = $False
)

# ======================= API app registration ==============================

# Creating app registration for the API 
$apiApps = az ad app list --display-name "$($apiAppName)-api" --filter "displayname eq '$($apiAppName)-api'"  | convertfrom-json
if ($apiApps.length -eq 0) {
    
    Write-Host "No API app registrations found - creating one"

    # Create app registration if doesn't exist with specified roles
    $apiApp = az ad app create `
        --display-name "$($apiAppName)-api" `
        --sign-in-audience $signInAudience `
        --identifier-uris "api://$($apiAppName)" `
        --output json | convertfrom-json
    
    # Create service principal for the Api app
    $apiAppSP = az ad sp create --id $apiApp.id | convertfrom-json

    Write-Host "Created API app with AppId: $($apiApp.appId) and Service Principal $($apiAppSP.id)"

}
elseif ($apiApps.length -eq 1) {
    $apiApp = $apiApps[0]
    $exisitngSPs = az ad sp list --display-name $apiApp.displayName | convertfrom-json
    $apiAppSP = $exisitngSPs[0]
    Write-Host "Found exisitng API app with AppId: $($apiApp.appId) and Service Principal $($apiAppSP.id)"
}
else {
    throw 'Multiple API app registrtions found'
}

# Creates lists of API roles to add
$apiRoleIds = @{}

$apiRoleDefs = New-Object System.Collections.ArrayList
foreach ($apiRole in $apiRoles) {
    $existingRole = $apiApp.appRoles.Where({ $_.value -eq $apiRole })
    if ($existingRole) {
        $roleId = $existingRole.id
    }
    else {
        $roleId = [Guid]::NewGuid().ToString()
    }
    $roleDefinition = @{ 
        allowedMemberTypes = @("Application")
        description        = $apiRole
        displayName        = $apiRole
        value              = $apiRole
        isEnabled          = "true"  
        id                 = $roleId            
    }
    $apiRoleDefs.Add($roleDefinition)       
    $apiRoleIds.Add($apiRole, $roleId)
}

# check if default role added
$existingRole = $apiApp.appRoles | Where-Object { $_.value -eq 'Api.Access' }
if ($existingRole) {
    $roleId = $existingRole.id
}
else {
    $roleId = [Guid]::NewGuid().ToString()
}
$apiRoleDefs.Add(@{
        allowedMemberTypes = @("Application")
        description        = 'Default Api access role'
        displayName        = 'Default Api access role'
        value              = 'Api.Access'
        isEnabled          = "true"     
        id                 = $roleId
    })
$apiRoleIds.Add('Api.Access', $roleId)


# prepare input json file for app roles
$apiRolesJson = $apiRoleDefs | ConvertTo-Json
if ($apiRoleDefs.Count -eq 1) {
    "[$($apiRolesJson)]" | Out-File "app-roles.json" -Force
}
else {
    $apiRolesJson | Out-File "app-roles.json" -Force
}

# update app roles for the API app
az ad app update `
    --id $apiApp.appId `
    --app-roles @app-roles.json `
    --output json | convertfrom-json

Write-Host "Updated $($apiRoleDefs.Count) App role(s) for the API app $($apiApp.appId)"

# ======================= API clients app registrations ==============================

if ($clientApps.Count -eq 0) {
    $clientApps = @{default = @('Api.Access') }
}

$clientAppsSPs = @{}
$clientAppsRoleAssignments = @{}

# Creating app registrations for API clients
foreach ($clientId in $clientApps.Keys) {    

    $apiClientAppName = "$($apiAppName)-api-client-$($clientId)"
    $existingClientApps = az ad app list --display-name $apiClientAppName --filter "displayname eq '$apiClientAppName'"  | convertfrom-json
    if ($existingClientApps.length -eq 0) {
    
        Write-Host "No API Client app registration found for client '$($clientId)' - creating one"
   
        # Create app registration for the client
        $apiClientApp = az ad app create `
            --display-name $apiClientAppName `
            --sign-in-audience $signInAudience `
            --output json | convertfrom-json
        $clientAppsRoleAssignments.Add($apiClientApp.appId, $clientApps[$clientId])
        Write-Host "Created app registation for API client '$($apiClientAppName)' with Id $($apiClientApp.id) and AppId: $($apiClientApp.appId)"
    
        # Create service principal for the Api client app
        $apiClientAppSP = az ad sp create --id $apiClientApp.id  | convertfrom-json                
        $clientAppsSPs.Add($apiClientApp.appId, $apiClientAppSP.id)

        # Generate client secret
        $clientSecret = az ad app credential reset --id $apiClientApp.appId --display-name 'Api client secret' | convertfrom-json

        # Add secret to key vault
        $secretName = "$($apiAppName)-client-$($clientId)-secret"
        $secretValue = $clientSecret.password 
        $kvSecret = az keyvault secret set --name $secretName --vault-name $keyVaultName --value $secretValue | convertfrom-json
        $kvSecretId = $kvSecret.id

        Write-Host "Client secret added to Key Vault with ID: $kvSecretId"               

        # update tags using graph api
        if($autoRotateSecrets) {
            $kvSecretId = $kvSecretId -replace ".{33}$" #remove secret version i.e. last 33 chars
            $tags = @("owners-$($clientAppsOwners)", "auto-rotate-$($kvSecretId)")            
        } else {
            $tags = @("owners-$($clientAppsOwners)")
        }

        $token = (az account get-access-token --resource-type ms-graph | ConvertFrom-Json).accessToken
        $headers = @{
            "Authorization"="Bearer $token"
            "Content-Type"="application/json"
        }
        $body = @{
            'tags' = $tags
        } 
        $bodyJson = $body | ConvertTo-Json
        Invoke-RestMethod -Method Patch -Uri "https://graph.microsoft.com/v1.0/applications(appId='$($apiClientApp.appId)')" -Headers $headers -Body $bodyJson        

        Write-Host "Tags updated for the client app: $($apiClientApp.appId)" 

    }
    elseif ($existingClientApps.length -eq 1) {
        $apiClientApp = $existingClientApps[0]
        $clientAppsRoleAssignments.Add($apiClientApp.appId, $clientApps[$clientId])

        $exisitngSPs = az ad sp list --display-name $apiClientApp.displayName | convertfrom-json
        $clientAppsSPs.Add($apiClientApp.appId, $exisitngSPs[0].id)
        Write-Host "Found exisitng app registration for API client '$($apiClientAppName)' with AppId: $($apiClientApp.appId)"
    }
    else {
        throw 'Multiple API client app registrtions found'
    }
}

# ======================= API permissions assignments ==============================

# add permissions for client apps to specified API roles
foreach ($clientId in $clientAppsRoleAssignments.Keys) {
    $clientRoles = $clientAppsRoleAssignments[$clientId] 

    $rolesList = New-Object System.Collections.ArrayList
    foreach ($role in $clientRoles) {
        $rolesList.Add( @{ 
                id   = $apiRoleIds[$role]
                type = "Role"
            })        
    }

    $permissionsJson = @{ 
        resourceAppId  = $apiApp.appId
        resourceAccess = $rolesList.ToArray()
    } | ConvertTo-Json
    
    "[$($permissionsJson)]" | Out-File "client-permissions.json" -Force
    
    $apiClientApp = az ad app update `
        --id $clientId `
        --required-resource-accesses @client-permissions.json

    Write-Host "$($rolesList.Count) API role(s) assigned for client $($clientAppsSPs[$clientId])"
    
    # Grant admin consent to API permissions for the client app if not already granted
    $existingGrants = (az rest --method GET `
            --uri "https://graph.microsoft.com/v1.0/servicePrincipals/$($clientAppsSPs[$clientId])/appRoleAssignments" `
        | ConvertFrom-Json).value

    foreach ($role in $clientRoles) {

        $roleGrant = $existingGrants  | Where-Object { $_.appRoleId -eq $apiRoleIds[$role] }

        if (!$roleGrant) {
            $body = @"
{ \"principalId\": \"$($clientAppsSPs[$clientId])\", \"resourceId\": \"$($apiAppSP.id)\", \"appRoleId\": \"$($apiRoleIds[$role])\" }
"@
            $result = az rest --method POST `
                --uri "https://graph.microsoft.com/v1.0/servicePrincipals/$($clientAppsSPs[$clientId])/appRoleAssignments"  `
                --headers "Content-Type=application/json" `
                --body $body
            
            Write-Host "Admin consent for client $($clientAppsSPs[$clientId]) and role $($apiRoleIds[$role]) granted"
        }
        else {
            Write-Host "Admin consent for client $($clientAppsSPs[$clientId]) and role $($apiRoleIds[$role]) already granted"
        }   
    }
}

# set pipleline variables
Write-Host "##vso[task.setvariable variable=aadApiId;issecret=false]$($apiApp.appId)"
Write-Host "##vso[task.setvariable variable=aadApiClientIds;issecret=false]$($clientAppsRoleAssignments.Keys -join ',')"
