# Script for uploading data to a table in Azure Storage Table from a csv file

[CmdletBinding()]
param (
    [Parameter(Mandatory)][string]$subscriptionId,
    [Parameter(Mandatory)][string]$resourceGroupName,
    [Parameter(Mandatory)][string]$storageAccountName,
    [Parameter(Mandatory)][string]$tableName,
    [Parameter(Mandatory)][string]$csvFilePath
)

# get storage account connection string
$cs = az storage account show-connection-string --name $storageAccountName --resource-group $resourceGroupName --subscription $subscriptionId | convertfrom-json

# load the csv file
$csvContents = Import-Csv -Path $csvFilePath
$csvHeaders = ($CsvContents[0] | Get-Member -MemberType NoteProperty).Name

# foreach row in the csv file create an entity in the table
Foreach ($csvContent in $csvContents) {

    $entity = New-Object System.Collections.ArrayList
    Foreach ($csvHeader in $csvHeaders) {
        if (!$csvHeader.Contains('@type')) { # ignore the @type property
            $value = $csvContent.$csvHeader
            if ([string]::IsNullOrEmpty($value)) {
                $value = $null
            }
            else {
                $value = '"' + $value + '"'
            }
            
            $property = $csvHeader + "=" + $value
            $entity.Add($property)
        }
    }

    Write-Host "Inserting the entity: $entity"
    az storage entity insert --entity @entity --if-exists replace --table-name $tableName --connection-string $cs.connectionString    
}