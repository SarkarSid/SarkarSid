﻿# Script to add provided IP addresses to Storage Account network rules

[CmdletBinding()]
 param (
    [Parameter(Mandatory)][string]$resourceGroupName, 
    [Parameter(Mandatory)][string]$storageAccountName,
    [Parameter(Mandatory)][string]$allowedIPs
)

foreach ($ip in $allowedIPs.Split(',')) {
    az storage account network-rule add --account-name $storageAccountName --resource-group $resourceGroupName --ip-address $ip
    Write-Host "Added rule for IP address $ip to Storage Account $storageAccountName"
}