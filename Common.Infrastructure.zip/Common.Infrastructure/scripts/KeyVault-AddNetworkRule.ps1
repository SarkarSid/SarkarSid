﻿# Script to add provided IP addresses to Key Vault network rules

[CmdletBinding()]
 param (
     [Parameter(Mandatory)][string]$keyVaultName,
     [Parameter(Mandatory)][string]$allowedIPs
)

foreach ($ip in $allowedIPs.Split(',')) {
    az keyvault network-rule add --name $keyVaultName --ip-address $ip
    Write-Host "Added rule for IP address $ip to Key Vault $keyVaultName"
}