# Script for assigning Graph API permissions to exisitng service principlas
[CmdletBinding()]
param (
    [Parameter(Mandatory, HelpMessage="Service principal name")]
    [string] $servicePrincipalName,    
    [Parameter(Mandatory, HelpMessage="Array of graph API permissions add e.g. Directory.Read.All")]
    [string[]] $graphPermissions
)

$token = (az account get-access-token --resource-type ms-graph | ConvertFrom-Json).accessToken

$headers = @{
    Authorization="Bearer $token"
}
$graphSPId = (Invoke-RestMethod -Method Get -Uri "https://graph.microsoft.com/v1.0/servicePrincipals?`$filter=displayName eq 'Microsoft Graph'&`$select=id" -Headers $headers).value.id

$appSPId = (Invoke-RestMethod -Method Get -Uri "https://graph.microsoft.com/v1.0/servicePrincipals?`$filter=displayName eq '$servicePrincipalName'&`$select=id" -Headers $headers).value.id

$allGraphRoles = (Invoke-RestMethod -Method Get -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$graphSPId/appRoles" -Headers $headers).value
$existingAppRoles = (Invoke-RestMethod -Method Get -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$appSPId/appRoleAssignments" -Headers $headers).value

foreach($permission in $graphPermissions){
    $permissionId = ($allGraphRoles | Where-Object value -eq $permission).Id 
    if ($existingAppRoles | Where-Object appRoleId -eq $permissionId) {
        Write-Host "Permission $permission already assigned"
    } else {
        $headers = @{
            "Authorization"="Bearer $token"
            "Content-Type"="application/json"
        }
        $body = @{
            'principalId' = $appSPId
            'resourceId' = $graphSPId
            'appRoleId' = $permissionId
        } 
        $bodyJson = $body | ConvertTo-Json

        Invoke-RestMethod -Method Post -Uri "https://graph.microsoft.com/v1.0/servicePrincipals/$appSPId/appRoleAssignments" -Headers $headers -Body $bodyJson        
        Write-Host "Permission $permission assigned successfully"
    }
}