param(
    [Parameter(Mandatory = $true)]
    [string]$dbPat, # Databricks Personal Access Token
    [Parameter(Mandatory = $true)]
    [string]$dbwInstance, # Databricks Workspace Instance URL
    [Parameter(Mandatory = $true)]
    [string]$workspaceName,
    [Parameter(Mandatory = $true)]
    [string]$subscriptionId,
    [Parameter(Mandatory = $true)]
    [string]$resourceGroupName,
    [Parameter(Mandatory = $true)]
    [string]$credentialName,
    [Parameter(Mandatory = $true)]
    [string]$accessConnectorId,
    [Parameter(Mandatory = $true)]
    [string]$externalLocationName,
    [string]$storageAccount,
    [Parameter(Mandatory = $true)]
    [string]$storageContainer,
    [Parameter(Mandatory = $true)]
    [string]$catalogName,
    [Parameter(Mandatory = $false)]
    [bool]$createCatalog = $false # Default is to execute
)

function New-StorageCredential {
    # Check if the storage credential already exists
    try {
        $existingCredentialResponse = Invoke-RestMethod -Uri "$dbwInstance/api/2.0/unity-catalog/storage-credentials/$credentialName" -Method Get -Headers @{
            "Authorization" = "Bearer $dbPat"
        }

        # If the request did not throw an exception, the credential exists
        Write-Host "Storage credential '$credentialName' already exists. Skipping creation."
        return
    }
    catch {
        # If an exception is caught, check if it's because the credential was not found
        if ($_.Exception.Response.StatusCode -eq 'NotFound') {
            # Credential does not exist, proceed with creation
        }
        else {
            # An error other than NotFound occurred, log it and exit
            Write-Host "Failed to check existence of storage credential '$credentialName'. Error: $_"
            return
        }
    }

    # Construct JSON payload to create the storage credential
    $jsonPayloadCredential = @{
        name                   = $credentialName
        azure_managed_identity = @{
            access_connector_id = $accessConnectorId
        }
    } | ConvertTo-Json

    # REST API call to create the storage credential
    try {
        $credentialResponse = Invoke-RestMethod -Uri "$dbwInstance/api/2.0/unity-catalog/storage-credentials" -Method Post -Headers @{
            "Authorization" = "Bearer $dbPat"
            "Content-Type"  = "application/json"
        } -Body $jsonPayloadCredential

        Write-Host "Storage credential created successfully. Response: $credentialResponse"
    }
    catch {
        Write-Host "Failed to create storage credential '$credentialName'. Error: $_"
    }
    
}

function New-ExternalLocation {
    # Check if the external location already exists
    try {
        $existingLocationResponse = Invoke-RestMethod -Uri "$dbwInstance/api/2.0/unity-catalog/external-locations/$externalLocationName" -Method Get -Headers @{
            "Authorization" = "Bearer $dbPat"
        }

        # If the request did not throw an exception, the location exists
        Write-Host "External location '$externalLocationName' already exists. Skipping creation."
        return
    }
    catch {
        # If an exception is caught, assume the location does not exist and proceed with creation
        if ($_.Exception.Response.StatusCode -ne 'NotFound') {
            Write-Error "Failed to check existence of external location '$externalLocationName'. Error: $_"
            return
        }
    }

    # Construct JSON payload to create the external location
    $jsonPayloadExternalLocation = @{
        name            = $externalLocationName
        url             = "abfss://$storageContainer@$storageAccount.dfs.core.windows.net/"
        credential_name = $credentialName
    } | ConvertTo-Json

    # REST API call to create the external location
    try {
        $externalLocationResponse = Invoke-RestMethod -Uri "$dbwInstance/api/2.1/unity-catalog/external-locations" -Method Post -Headers @{
            "Authorization" = "Bearer $dbPat"
            "Content-Type"  = "application/json"
        } -Body $jsonPayloadExternalLocation

        Write-Host "External location '$externalLocationName' created successfully. Response: $externalLocationResponse"
    }
    catch {
        Write-Error "Failed to create external location '$externalLocationName'. Error: $_"
        
    }
    
}

function New-Catalog {
    if ($createCatalog) {
        try {
            # Construct JSON payload to create the catalog
            $jsonPayloadCatalog = @{
                name         = $catalogName
                storage_root = "abfss://$storageContainer@$storageAccount.dfs.core.windows.net/"
            } | ConvertTo-Json
        
            # REST API call to create the catalog
            $catalogResponse = Invoke-RestMethod -Uri "$dbwInstance/api/2.0/unity-catalog/catalogs" -Method Post -Headers @{
                "Authorization" = "Bearer $dbPat"
                "Content-Type"  = "application/json"
            } -Body $jsonPayloadCatalog
        
            Write-Host "Catalog created successfully. Response: $catalogResponse"
        }
        catch {
            Write-Host "Failed to create catalog. Error: $($_.Exception.Message)"
        }
    }
    else {
        Write-Host "Skipping catalog creation because \$createCatalog is set to $createCatalog."
    }
  
}

# Execute the functions in the correct order considering their dependencies
New-StorageCredential
New-ExternalLocation
New-Catalog