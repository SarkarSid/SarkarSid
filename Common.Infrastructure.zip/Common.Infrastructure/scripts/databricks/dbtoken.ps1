param(
    [Parameter(Mandatory=$true)]
    [string]$workspaceName,
    [string]$subscriptionId,
    [string]$resourceGroupName
)

function Get-WorkspaceId {
    az resource show --resource-type Microsoft.Databricks/workspaces --resource-group $resourceGroupName --name $workspaceName --query id --output tsv --subscription $subscriptionId
}

function Get-DbPat {
    $Token = (az account get-access-token --resource 2ff814a6-3304-4ab8-85cb-cd0e6f879c1d | ConvertFrom-Json).accessToken
    $AzToken = (az account get-access-token --resource https://management.core.windows.net/ | ConvertFrom-Json).accessToken

    # Obtain Databricks Personal Access Token (PAT)
    $DbPat = Invoke-RestMethod -Uri "https://westeurope.azuredatabricks.net/api/2.0/token/create" -Method Post -Headers @{
        "Authorization" = "Bearer $Token"
        "X-Databricks-Azure-SP-Management-Token" = $AzToken
        "X-Databricks-Azure-Workspace-Resource-Id" = (Get-WorkspaceId)
    } -Body '{ "lifetime_seconds": 1200, "comment": "Azure DevOps pipeline" }' | Select-Object -ExpandProperty token_value

    # Set DB_PAT as an environment variable
    $env:DB_PAT = $DbPat

    Write-Host "##vso[task.setvariable variable=DB_PAT]$DbPat"
}

switch ($Operation) {
    "GetWorkspaceId" {
        Get-WorkspaceId
    }
    "GetDbPat" {
        Get-DbPat
    }
    "CreateCluster" {
        Create-Cluster
    }
    default {
        Write-Host "Generating Token..."
        Get-WorkspaceId
        Get-DbPat
    }
}