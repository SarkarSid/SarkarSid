param(
    [Parameter(Mandatory = $true)]
    [string]$dbPat,
    [Parameter(Mandatory = $true)]
    [string]$dbwInstance,
    [Parameter(Mandatory = $true)]
    [string]$credentialName,
    [Parameter(Mandatory = $true)]
    [string]$externalLocationName,
    [Parameter(Mandatory = $true)]
    [string]$catalogName,
    [Parameter(Mandatory = $true)]
    [string]$newOwner
)

function Update-StorageCredentialOwner {
    $jsonPayloadStorageCredentials = @{
        name            = $credentialName
        credential_name = $credentialName
        owner           = $newOwner
    } | ConvertTo-Json

    $uri = "$dbwInstance/api/2.1/unity-catalog/storage-credentials/$credentialName"
    $headers = @{
        "Authorization" = "Bearer $dbPat"
        "Content-Type"  = "application/json"
    }

    try {
        $response = Invoke-RestMethod -Uri $uri -Method Patch -Headers $headers -Body $jsonPayloadStorageCredentials
        Write-Host "Storage credential owner updated successfully."
    }
    catch {
        Write-Host "Error during storage credential owner update: $($_.Exception.Message)"
    }
   
}

function Update-ExternalLocationOwner {
    $locations = $externalLocationName -split ','
    foreach ($locationName in $locations) {
        $uriCheck = "$dbwInstance/api/2.1/unity-catalog/external-locations/$locationName"
        $headers = @{
            "Authorization" = "Bearer $dbPat"
            "Content-Type"  = "application/json"
        }

        # Check if the external location exists
        try {
            $responseCheck = Invoke-RestMethod -Uri $uriCheck -Method Get -Headers $headers
            # If the location exists, proceed with the update
            $jsonPayloadExternalLocation = @{
                name  = $locationName
                owner = $newOwner
            } | ConvertTo-Json

            $uriUpdate = "$dbwInstance/api/2.1/unity-catalog/external-locations/$locationName"
            try {
                $responseUpdate = Invoke-RestMethod -Uri $uriUpdate -Method Patch -Headers $headers -Body $jsonPayloadExternalLocation
                Write-Host "External location '$locationName' owner updated successfully."
            }
            catch {
                if ($_.Exception.Response.StatusCode -eq 'Forbidden') {
                    Write-Host "Access denied when trying to update external location '$locationName'. Check if the token has the necessary permissions."
                } else {
                    Write-Host "Error during external location '$locationName' owner update: $($_.Exception.Message)"
                }
            }
        }
        catch {
            Write-Host "External location '$locationName' does not exist. Skipping update."
        }
    }
}
function Update-CatalogOwner {
    $jsonPayload = @{
        catalog_name = $catalogName
        owner        = $newOwner
    } | ConvertTo-Json

    $uri = "$dbwInstance/api/2.1/unity-catalog/catalogs/$catalogName"
    $headers = @{
        "Authorization" = "Bearer $dbPat"
        "Content-Type"  = "application/json"
    }

    try {
        $response = Invoke-RestMethod -Uri $uri -Method Patch -Headers $headers -Body $jsonPayload
        Write-Host "Catalog owner updated successfully."
    }
    catch {
        Write-Host "Error during catalog owner update: $($_.Exception.Message)"
    }
}

# Call the update functions
Update-CatalogOwner
Update-ExternalLocationOwner
Update-StorageCredentialOwner