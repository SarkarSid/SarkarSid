param(
    [Parameter(Mandatory = $true)]
    [string]$clusterName,
    [string]$clusterSize,
    [string]$nodeTypeId,
    [string]$dbwInstance,
    [string]$dbPat
)


function Get-ExistingCluster {
    $headers = @{
        "Authorization" = "Bearer $dbPat"
    }
    $uri = "$dbwInstance/api/2.0/clusters/list"
    $response = Invoke-RestMethod -Uri $uri -Method Get -Headers $headers
    $clusters = $response.clusters

    $existingCluster = $clusters | Where-Object { $_.cluster_name -eq $clusterName }
    return $existingCluster
}


function New-Cluster {
    $MINWORKERS, $MAXWORKERS = switch ($clusterSize) {
        "Small" { 1, 4 }
        "Medium" { 4, 8 }
        "Large" { 8, 16 }
    }

    $clusterConfig = @{
        autoscale                    = @{
            min_workers = $MINWORKERS
            max_workers = $MAXWORKERS
        }
        cluster_name                 = $clusterName
        spark_version                = "14.3.x-scala2.12"
        spark_conf                   = @{
            "spark.databricks.delta.preview.enabled" = "true"
        }
        azure_attributes             = @{
            first_on_demand    = 1
            availability       = "SPOT_WITH_FALLBACK_AZURE"
            spot_bid_max_price = -1
        }
        node_type_id                 = $nodeTypeId
        driver_node_type_id          = $nodeTypeId
        ssh_public_keys              = @()
        custom_tags                  = @{}
        spark_env_vars               = @{
            PYSPARK_PYTHON = "/databricks/python3/bin/python3"
        }
        autotermination_minutes      = 10
        enable_elastic_disk          = $true
        enable_local_disk_encryption = $false
        data_security_mode           = "USER_ISOLATION"
        runtime_engine               = "STANDARD"
        cluster_source               = "UI"
        init_scripts                 = @()
    }

    $jsonPayload = $clusterConfig | ConvertTo-Json -Depth 10

    Write-Host "JSON Payload:"
    Write-Host $jsonPayload
    $response = Invoke-RestMethod -Method Post -Headers @{ 'Authorization' = "Bearer $dbPat"; 'Content-Type' = 'application/json' } -Body $jsonPayload -Uri "$dbwInstance/api/2.0/clusters/create"

    Write-Host "Response from Databricks:"
    Write-Host $response
    if ($response -match "error_code") {
        Write-Error "Error creating the cluster: $response"
        exit 1
    }
}

switch ($Operation) {
    "CreateCluster" {
        $existingCluster = Get-ExistingCluster
        if ($existingCluster) {
            Write-Host "Cluster `"$clusterName`" already exists. Skipping creation."
        } else {
            Write-Host "Creating Cluster..."
            New-Cluster
        }
    }
    default {
        Write-Host "Creating Cluster..."
        $existingCluster = Get-ExistingCluster
        if ($existingCluster) {
            Write-Host "Cluster `"$clusterName`" already exists. Skipping creation."
        } else {
            New-Cluster
        }
    }
}